import { RedirectToSignIn } from "@clerk/nextjs";

export default function SignUpPage() {
  return <RedirectToSignIn />;
}
