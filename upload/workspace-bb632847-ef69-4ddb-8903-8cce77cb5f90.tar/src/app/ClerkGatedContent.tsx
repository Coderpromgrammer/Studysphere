"use client";

import dynamic from "next/dynamic";

// Dynamic import to avoid SSR issues with Clerk
const AuthenticatedApp = dynamic(
  () =>
    import("@/components/AuthenticatedApp").then((mod) => mod.AuthenticatedApp),
  {
    ssr: false,
    loading: () => (
      <div className="min-h-screen flex items-center justify-center animated-gradient-bg">
        <div className="glass-card rounded-2xl p-8 text-center">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-indigo-500 flex items-center justify-center mx-auto mb-4">
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          </div>
          <p className="text-sm text-muted-foreground">Loading StudySphere...</p>
        </div>
      </div>
    ),
  }
);

export default function ClerkGatedContent() {
  // In demo mode, we always render the AuthenticatedApp directly
  // When Clerk is configured, this would check auth state
  const hasClerkKey = !!process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY;

  if (!hasClerkKey) {
    return <AuthenticatedApp />;
  }

  // With Clerk, we would gate content behind auth
  // For now, still render the app (Clerk handles the gating)
  return <AuthenticatedApp />;
}
