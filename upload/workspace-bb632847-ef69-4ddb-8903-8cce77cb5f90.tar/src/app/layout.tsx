import type { Metadata } from "next";
import { ThemeProvider } from "next-themes";
import { SafeClerkProvider } from "@/components/SafeClerkProvider";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { Toaster } from "@/components/ui/sonner";
import "./globals.css";

export const metadata: Metadata = {
  title: "StudySphere AI — Smart Learning Platform",
  description:
    "AI-powered learning platform for students (Classes 6-12). Features AI question solving, quiz generation, smart notes, collaborative classrooms, and progress tracking.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased">
        <SafeClerkProvider>
          <ThemeProvider
            attribute="class"
            defaultTheme="light"
            enableSystem
            disableTransitionOnChange
          >
            <ErrorBoundary>
              {children}
            </ErrorBoundary>
            <Toaster />
          </ThemeProvider>
        </SafeClerkProvider>
      </body>
    </html>
  );
}
