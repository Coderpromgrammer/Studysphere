// ==========================================
// AI Quiz Generation API — HuggingFace + z-ai fallback
// ==========================================

import { NextRequest, NextResponse } from "next/server";
import { buildQuizPrompt } from "@/lib/ai/prompts";
import { parseQuizResponse } from "@/lib/ai/parser";
import { checkRateLimit } from "@/lib/ai/rate-limit";
import type { Subject, QuizDifficulty, QuestionType } from "@/types";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { topic, subject = "math", difficulty = "medium", questionType = "mcq", count = 5 } = body as {
      topic: string;
      subject: Subject;
      difficulty: QuizDifficulty;
      questionType: QuestionType;
      count: number;
    };

    if (!topic?.trim()) {
      return NextResponse.json({ error: "Topic is required" }, { status: 400 });
    }

    const rateCheck = checkRateLimit("quiz");
    if (!rateCheck.allowed) {
      return NextResponse.json(
        { error: "Rate limit exceeded. Please wait a moment." },
        { status: 429 }
      );
    }

    const prompt = buildQuizPrompt(topic, subject, difficulty, questionType, count);
    let result = "";

    const HF_TOKEN = process.env.HUGGINGFACE_API_TOKEN;
    if (HF_TOKEN) {
      try {
        const response = await fetch(
          "https://api-inference.huggingface.co/models/Qwen/Qwen3-235B-A22B/v1/chat/completions",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${HF_TOKEN}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: "Qwen/Qwen3-235B-A22B",
              messages: [
                { role: "system", content: "You are a quiz generator. Return only valid JSON." },
                { role: "user", content: prompt },
              ],
              max_tokens: 4096,
              temperature: 0.4,
            }),
          }
        );
        if (response.ok) {
          const data = await response.json();
          result = data.choices?.[0]?.message?.content || "";
        }
      } catch {
        // Fall through
      }
    }

    if (!result) {
      try {
        const ZAI = (await import("z-ai-web-dev-sdk")).default;
        const zai = await ZAI.create();
        const completion = await zai.chat.completions.create({
          messages: [
            { role: "system", content: "You are a quiz generator for Indian school students. Return only valid JSON." },
            { role: "user", content: prompt },
          ],
          max_tokens: 4096,
          temperature: 0.4,
        });
        result = completion.choices?.[0]?.message?.content || "";
      } catch (err) {
        console.error("z-ai fallback failed:", err);
        return NextResponse.json(
          { error: "AI service unavailable. Please try again." },
          { status: 503 }
        );
      }
    }

    const questions = parseQuizResponse(result);

    return NextResponse.json({
      success: true,
      questions,
      title: `${topic} - Quiz`,
      subject,
      difficulty,
      rawResponse: result,
    });
  } catch (error) {
    console.error("Quiz API error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
