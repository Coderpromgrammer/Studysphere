// ==========================================
// AI Solve API — HuggingFace + z-ai fallback
// ==========================================

import { NextRequest, NextResponse } from "next/server";
import { buildSolvePrompt } from "@/lib/ai/prompts";
import { parseSolveResponse } from "@/lib/ai/parser";
import { checkRateLimit } from "@/lib/ai/rate-limit";
import type { Subject, SolverMode } from "@/types";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { query, subject = "math", mode = "normal", imageUrl } = body as {
      query: string;
      subject: Subject;
      mode: SolverMode;
      imageUrl?: string;
    };

    if (!query?.trim()) {
      return NextResponse.json({ error: "Query is required" }, { status: 400 });
    }

    // Rate limiting
    const rateCheck = checkRateLimit("solve");
    if (!rateCheck.allowed) {
      return NextResponse.json(
        { error: "Rate limit exceeded. Please wait a moment." },
        { status: 429 }
      );
    }

    const prompt = buildSolvePrompt(query, subject, mode, !!imageUrl);

    // If image URL is provided, add image description context
    const fullPrompt = imageUrl
      ? `${prompt}\n\n[User attached an image. Image URL: ${imageUrl}]`
      : prompt;

    let result = "";

    // Try HuggingFace first
    const HF_TOKEN = process.env.HUGGINGFACE_API_TOKEN;
    if (HF_TOKEN) {
      try {
        const response = await fetch(
          "https://api-inference.huggingface.co/models/Qwen/Qwen3-235B-A22B/v1/chat/completions",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${HF_TOKEN}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: "Qwen/Qwen3-235B-A22B",
              messages: [
                { role: "system", content: "You are an expert tutor for Indian school students." },
                { role: "user", content: fullPrompt },
              ],
              max_tokens: 4096,
              temperature: 0.2,
            }),
          }
        );

        if (response.ok) {
          const data = await response.json();
          result = data.choices?.[0]?.message?.content || "";
        }
      } catch {
        // HuggingFace failed, fall through to z-ai
      }
    }

    // Fallback to z-ai-web-dev-sdk
    if (!result) {
      try {
        const ZAI = (await import("z-ai-web-dev-sdk")).default;
        const zai = await ZAI.create();
        const completion = await zai.chat.completions.create({
          messages: [
            { role: "system", content: "You are an expert tutor for Indian school students. Provide clear, step-by-step solutions." },
            { role: "user", content: fullPrompt },
          ],
          max_tokens: 4096,
          temperature: 0.2,
        });
        result = completion.choices?.[0]?.message?.content || "";
      } catch (err) {
        console.error("z-ai fallback failed:", err);
        return NextResponse.json(
          { error: "AI service unavailable. Please try again." },
          { status: 503 }
        );
      }
    }

    const parsed = parseSolveResponse(result);

    return NextResponse.json({
      success: true,
      result: {
        answer: parsed.answer,
        steps: parsed.steps,
        explanation: parsed.explanation,
        subject,
        mode,
        imageUrl,
        timestamp: Date.now(),
      },
      rawResponse: result,
    });
  } catch (error) {
    console.error("Solve API error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
