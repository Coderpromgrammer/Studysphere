// ==========================================
// AI Summarize API — HuggingFace + z-ai fallback
// ==========================================

import { NextRequest, NextResponse } from "next/server";
import { buildSummarizePrompt } from "@/lib/ai/prompts";
import { parseSummarizeResponse } from "@/lib/ai/parser";
import { checkRateLimit } from "@/lib/ai/rate-limit";
import type { Subject } from "@/types";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { content, subject } = body as {
      content: string;
      subject?: Subject;
    };

    if (!content?.trim()) {
      return NextResponse.json({ error: "Content is required" }, { status: 400 });
    }

    const rateCheck = checkRateLimit("summarize");
    if (!rateCheck.allowed) {
      return NextResponse.json(
        { error: "Rate limit exceeded. Please wait a moment." },
        { status: 429 }
      );
    }

    const prompt = buildSummarizePrompt(content, subject);
    let result = "";

    const HF_TOKEN = process.env.HUGGINGFACE_API_TOKEN;
    if (HF_TOKEN) {
      try {
        const response = await fetch(
          "https://api-inference.huggingface.co/models/Qwen/Qwen3-235B-A22B/v1/chat/completions",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${HF_TOKEN}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: "Qwen/Qwen3-235B-A22B",
              messages: [
                { role: "system", content: "You are an AI study assistant that creates summaries and study notes." },
                { role: "user", content: prompt },
              ],
              max_tokens: 2048,
              temperature: 0.3,
            }),
          }
        );
        if (response.ok) {
          const data = await response.json();
          result = data.choices?.[0]?.message?.content || "";
        }
      } catch {
        // Fall through
      }
    }

    if (!result) {
      try {
        const ZAI = (await import("z-ai-web-dev-sdk")).default;
        const zai = await ZAI.create();
        const completion = await zai.chat.completions.create({
          messages: [
            { role: "system", content: "You are an AI study assistant that creates summaries and study notes. Return JSON format." },
            { role: "user", content: prompt },
          ],
          max_tokens: 2048,
          temperature: 0.3,
        });
        result = completion.choices?.[0]?.message?.content || "";
      } catch (err) {
        console.error("z-ai fallback failed:", err);
        return NextResponse.json(
          { error: "AI service unavailable. Please try again." },
          { status: 503 }
        );
      }
    }

    const parsed = parseSummarizeResponse(result);

    return NextResponse.json({
      success: true,
      ...parsed,
      rawResponse: result,
    });
  } catch (error) {
    console.error("Summarize API error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
