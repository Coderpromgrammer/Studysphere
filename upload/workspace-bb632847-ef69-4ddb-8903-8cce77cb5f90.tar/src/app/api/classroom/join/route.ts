// ==========================================
// Classroom Join API
// ==========================================

import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import { Room } from "@/lib/models";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { code, userId = "demo-user", userName = "Student" } = body as {
      code: string;
      userId: string;
      userName: string;
    };

    if (!code?.trim()) {
      return NextResponse.json({ error: "Room code is required" }, { status: 400 });
    }

    const db = await connectDB();

    if (!db) {
      // Demo mode
      return NextResponse.json({
        room: {
          id: `room-demo-${code}`,
          name: `Room ${code}`,
          code: code.toUpperCase(),
          subject: "math",
          createdBy: "teacher",
          members: [
            { id: "teacher", name: "Teacher", role: "teacher", joinedAt: new Date() },
            { id: userId, name: userName, role: "student", joinedAt: new Date() },
          ],
          isActive: true,
          createdAt: new Date(),
        },
        demo: true,
      });
    }

    const room = await Room.findOne({ code: code.toUpperCase(), isActive: true });
    if (!room) {
      return NextResponse.json({ error: "Room not found. Check the code and try again." }, { status: 404 });
    }

    // Check if already a member
    const isMember = room.members.some((m: { id: string }) => m.id === userId);
    if (!isMember) {
      room.members.push({ id: userId, name: userName, role: "student", joinedAt: new Date() });
      await room.save();
    }

    return NextResponse.json({ room });
  } catch (error) {
    console.error("Classroom Join error:", error);
    return NextResponse.json({ error: "Failed to join room" }, { status: 500 });
  }
}
