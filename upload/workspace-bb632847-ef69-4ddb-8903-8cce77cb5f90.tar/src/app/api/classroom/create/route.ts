// ==========================================
// Classroom Create API
// ==========================================

import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import { Room } from "@/lib/models";
import type { Subject } from "@/types";

function generateRoomCode(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, subject = "math", createdBy = "demo-user" } = body as {
      name: string;
      subject: Subject;
      createdBy: string;
    };

    if (!name?.trim()) {
      return NextResponse.json({ error: "Room name is required" }, { status: 400 });
    }

    const code = generateRoomCode();
    const db = await connectDB();

    const roomData = {
      name: name.trim(),
      code,
      subject,
      createdBy,
      members: [{ id: createdBy, name: "You", role: "teacher", joinedAt: new Date() }],
      isActive: true,
    };

    if (!db) {
      // Demo mode
      return NextResponse.json({
        room: {
          id: `room-${Date.now()}`,
          ...roomData,
          createdAt: new Date(),
        },
        demo: true,
      });
    }

    const room = await Room.create(roomData);
    return NextResponse.json({ room });
  } catch (error) {
    console.error("Classroom Create error:", error);
    return NextResponse.json({ error: "Failed to create room" }, { status: 500 });
  }
}
