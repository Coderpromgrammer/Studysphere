// ==========================================
// Classroom Messages API
// ==========================================

import { NextRequest, NextResponse } from "next/server";

// In-memory messages store (for demo mode)
const messagesStore = new Map<string, Array<{
  id: string;
  roomId: string;
  senderId: string;
  senderName: string;
  content: string;
  isAI: boolean;
  timestamp: number;
}>>();

export async function GET(req: NextRequest) {
  try {
    const roomId = req.nextUrl.searchParams.get("roomId");
    if (!roomId) {
      return NextResponse.json({ error: "Room ID is required" }, { status: 400 });
    }

    const messages = messagesStore.get(roomId) || [];
    return NextResponse.json({ messages });
  } catch (error) {
    console.error("Messages GET error:", error);
    return NextResponse.json({ messages: [] }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { roomId, senderId, senderName, content } = body as {
      roomId: string;
      senderId: string;
      senderName: string;
      content: string;
    };

    if (!roomId || !content?.trim()) {
      return NextResponse.json({ error: "Room ID and content are required" }, { status: 400 });
    }

    const message = {
      id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      roomId,
      senderId,
      senderName,
      content: content.trim(),
      isAI: false,
      timestamp: Date.now(),
    };

    // Store message
    if (!messagesStore.has(roomId)) {
      messagesStore.set(roomId, []);
    }
    messagesStore.get(roomId)!.push(message);

    // Check if message is a question — if so, generate AI response
    let aiMessage: typeof message | null = null;
    if (content.trim().endsWith("?")) {
      try {
        const ZAI = (await import("z-ai-web-dev-sdk")).default;
        const zai = await ZAI.create();
        const completion = await zai.chat.completions.create({
          messages: [
            {
              role: "system",
              content: "You are an AI tutor in a classroom. Answer student questions concisely and helpfully. Keep answers under 200 words. Use simple language for school students (Classes 6-12, Indian curriculum).",
            },
            { role: "user", content: content.trim() },
          ],
          max_tokens: 512,
          temperature: 0.4,
        });

        const aiResponse = completion.choices?.[0]?.message?.content || "";
        if (aiResponse) {
          aiMessage = {
            id: `msg-ai-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            roomId,
            senderId: "ai-tutor",
            senderName: "AI Tutor 🤖",
            content: aiResponse,
            isAI: true,
            timestamp: Date.now(),
          };
          messagesStore.get(roomId)!.push(aiMessage);
        }
      } catch (err) {
        console.error("AI response in classroom failed:", err);
      }
    }

    return NextResponse.json({
      success: true,
      message,
      aiMessage,
    });
  } catch (error) {
    console.error("Messages POST error:", error);
    return NextResponse.json({ error: "Failed to send message" }, { status: 500 });
  }
}
