// ==========================================
// User Progress API
// ==========================================

import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import { Progress } from "@/lib/models";

export async function GET(req: NextRequest) {
  try {
    const userId = req.nextUrl.searchParams.get("userId") || "demo-user";
    const db = await connectDB();

    if (!db) {
      // Demo mode — return sample progress data
      return NextResponse.json({
        progress: [
          { subject: "math", score: 72, quizzesTaken: 5, questionsAttempted: 40, correctAnswers: 29, streak: 3 },
          { subject: "science", score: 85, quizzesTaken: 7, questionsAttempted: 56, correctAnswers: 48, streak: 5 },
          { subject: "sanskrit", score: 60, quizzesTaken: 3, questionsAttempted: 24, correctAnswers: 14, streak: 1 },
          { subject: "sst", score: 78, quizzesTaken: 4, questionsAttempted: 32, correctAnswers: 25, streak: 2 },
        ],
        streak: { current: 3, longest: 7, lastActiveDate: new Date().toISOString().split("T")[0] },
        demo: true,
      });
    }

    const progress = await Progress.find({ userId });
    return NextResponse.json({ progress });
  } catch (error) {
    console.error("Progress GET error:", error);
    return NextResponse.json({ progress: [], error: "Failed to fetch progress" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { userId = "demo-user", subject, correct, total } = body as {
      userId: string;
      subject: string;
      correct: number;
      total: number;
    };

    const db = await connectDB();

    if (!db) {
      return NextResponse.json({ success: true, demo: true });
    }

    await Progress.findOneAndUpdate(
      { userId, subject },
      {
        $inc: {
          quizzesTaken: 1,
          questionsAttempted: total,
          correctAnswers: correct,
        },
        $set: { lastPracticed: new Date() },
      },
      { upsert: true, new: true }
    );

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Progress POST error:", error);
    return NextResponse.json({ error: "Failed to update progress" }, { status: 500 });
  }
}
