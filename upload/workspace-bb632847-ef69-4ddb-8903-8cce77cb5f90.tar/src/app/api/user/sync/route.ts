// ==========================================
// User Sync API
// ==========================================

import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import { User } from "@/lib/models";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { clerkId, name, email, avatar, classLevel, school, subjects } = body as {
      clerkId: string;
      name: string;
      email?: string;
      avatar?: string;
      classLevel?: number;
      school?: string;
      subjects?: string[];
    };

    if (!clerkId) {
      return NextResponse.json({ error: "clerkId is required" }, { status: 400 });
    }

    const db = await connectDB();

    if (!db) {
      return NextResponse.json({
        user: { id: clerkId, name: name || "Student", classLevel: classLevel || 10, demo: true },
      });
    }

    const user = await User.findOneAndUpdate(
      { clerkId },
      {
        name: name || "Student",
        ...(email && { email }),
        ...(avatar && { avatar }),
        ...(classLevel && { classLevel }),
        ...(school && { school }),
        ...(subjects && { subjects }),
      },
      { upsert: true, new: true }
    );

    return NextResponse.json({ user });
  } catch (error) {
    console.error("User Sync error:", error);
    return NextResponse.json({ error: "Failed to sync user" }, { status: 500 });
  }
}
