// ==========================================
// Root API Route
// ==========================================

import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    name: "StudySphere AI",
    version: "2.0.0",
    status: "running",
    endpoints: [
      "/api/ai/solve",
      "/api/ai/chat",
      "/api/ai/summarize",
      "/api/ai/quiz",
      "/api/ai/translate",
      "/api/notebook",
      "/api/classroom/create",
      "/api/classroom/join",
      "/api/classroom/messages",
      "/api/user/progress",
      "/api/user/sync",
    ],
  });
}
