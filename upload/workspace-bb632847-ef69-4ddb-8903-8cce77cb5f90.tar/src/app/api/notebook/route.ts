// ==========================================
// Notebook CRUD API
// ==========================================

import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import { Notebook } from "@/lib/models";

export async function GET(req: NextRequest) {
  try {
    const userId = req.nextUrl.searchParams.get("userId") || "demo-user";
    const db = await connectDB();

    if (!db) {
      // Demo mode — return empty array
      return NextResponse.json({ notes: [], demo: true });
    }

    const notes = await Notebook.find({ userId }).sort({ createdAt: -1 }).limit(100);
    return NextResponse.json({ notes });
  } catch (error) {
    console.error("Notebook GET error:", error);
    return NextResponse.json({ notes: [], error: "Failed to fetch notes" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { userId = "demo-user", title, content, summary, keyPoints, subject, tags, isAIGenerated, sourceType, fileName, imageUrl } = body;

    if (!title?.trim()) {
      return NextResponse.json({ error: "Title is required" }, { status: 400 });
    }

    const db = await connectDB();

    if (!db) {
      // Demo mode — return the note as if saved
      return NextResponse.json({
        note: {
          id: `note-${Date.now()}`,
          userId,
          title,
          content: content || "",
          summary: summary || "",
          keyPoints: keyPoints || [],
          subject,
          tags: tags || [],
          isAIGenerated: isAIGenerated || false,
          sourceType: sourceType || "text",
          fileName,
          imageUrl,
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        demo: true,
      });
    }

    const note = await Notebook.create({
      userId,
      title,
      content: content || "",
      summary: summary || "",
      keyPoints: keyPoints || [],
      subject,
      tags: tags || [],
      isAIGenerated: isAIGenerated || false,
      sourceType: sourceType || "text",
      fileName,
      imageUrl,
    });

    return NextResponse.json({ note });
  } catch (error) {
    console.error("Notebook POST error:", error);
    return NextResponse.json({ error: "Failed to save note" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const noteId = req.nextUrl.searchParams.get("id");
    if (!noteId) {
      return NextResponse.json({ error: "Note ID is required" }, { status: 400 });
    }

    const db = await connectDB();
    if (!db) {
      return NextResponse.json({ success: true, demo: true });
    }

    await Notebook.findByIdAndDelete(noteId);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Notebook DELETE error:", error);
    return NextResponse.json({ error: "Failed to delete note" }, { status: 500 });
  }
}
