"use client";

import dynamic from "next/dynamic";

// Dynamic import to ensure client-side rendering
const ClerkGatedContent = dynamic(
  () =>
    import("./ClerkGatedContent").then((mod) => mod.default),
  {
    ssr: false,
    loading: () => (
      <div className="min-h-screen flex items-center justify-center animated-gradient-bg">
        <div className="glass-card rounded-2xl p-8 text-center">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-indigo-500 flex items-center justify-center mx-auto mb-4">
            <svg className="animate-spin w-6 h-6 text-white" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
            </svg>
          </div>
          <h2 className="text-lg font-bold gradient-text">StudySphere AI</h2>
          <p className="text-sm text-muted-foreground mt-1">Loading your learning companion...</p>
        </div>
      </div>
    ),
  }
);

export default function Home() {
  return <ClerkGatedContent />;
}
