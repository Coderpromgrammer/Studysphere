// ==========================================
// StudySphere AI — TypeScript Types
// ==========================================

// Navigation
export type PageId =
  | "dashboard"
  | "solver"
  | "quiz"
  | "notebook"
  | "classroom"
  | "progress"
  | "settings"
  | "math-helper"
  | "science-helper"
  | "sanskrit-helper"
  | "sst-helper";

export interface NavItem {
  id: PageId;
  label: string;
  icon: string;
  href?: string;
}

// Subjects
export type Subject = "math" | "science" | "sanskrit" | "sst";

export const SUBJECT_CONFIG: Record<Subject, { label: string; color: string; icon: string }> = {
  math: { label: "Mathematics", color: "text-amber-500", icon: "Calculator" },
  science: { label: "Science", color: "text-emerald-500", icon: "FlaskConical" },
  sanskrit: { label: "Sanskrit", color: "text-red-500", icon: "BookOpen" },
  sst: { label: "Social Studies", color: "text-blue-500", icon: "Globe" },
};

// Solver
export type SolverMode = "easy" | "normal" | "exam";

export interface SolverResult {
  answer: string;
  steps: string[];
  explanation: string;
  subject: Subject;
  mode: SolverMode;
  imageUrl?: string;
  timestamp: number;
}

// Quiz
export type QuizDifficulty = "easy" | "medium" | "hard";
export type QuestionType = "mcq" | "true-false" | "short-answer";

export interface QuizQuestion {
  id: string;
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  type: QuestionType;
  subject: Subject;
  difficulty: QuizDifficulty;
}

export interface Quiz {
  id: string;
  title: string;
  subject: Subject;
  difficulty: QuizDifficulty;
  questions: QuizQuestion[];
  score: number;
  totalQuestions: number;
  completedAt?: number;
  createdAt: number;
}

// Notebook
export interface Note {
  id: string;
  title: string;
  content: string;
  summary: string;
  keyPoints: string[];
  subject?: Subject;
  tags: string[];
  isAIGenerated: boolean;
  sourceType: "text" | "file" | "photo" | "quick";
  fileName?: string;
  imageUrl?: string;
  createdAt: number;
  updatedAt: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: number;
}

// Classroom
export interface ClassroomRoom {
  id: string;
  name: string;
  subject: Subject;
  code: string;
  createdBy: string;
  members: ClassroomMember[];
  createdAt: number;
}

export interface ClassroomMember {
  id: string;
  name: string;
  avatar?: string;
  role: "teacher" | "student";
  isOnline: boolean;
}

export interface ClassroomMessage {
  id: string;
  roomId: string;
  senderId: string;
  senderName: string;
  content: string;
  isAI: boolean;
  timestamp: number;
}

export interface ClassroomAnnouncement {
  id: string;
  roomId: string;
  title: string;
  content: string;
  createdBy: string;
  createdAt: number;
}

// Progress
export interface SubjectProgress {
  subject: Subject;
  score: number;
  quizzesTaken: number;
  questionsAttempted: number;
  correctAnswers: number;
  streak: number;
  lastPracticed: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt?: number;
  progress: number;
  maxProgress: number;
}

export interface DailyStreak {
  current: number;
  longest: number;
  lastActiveDate: string;
}

// User
export interface UserProfile {
  id: string;
  name: string;
  email?: string;
  avatar?: string;
  classLevel: number;
  school?: string;
  subjects: Subject[];
  createdAt: number;
}

// AI
export interface AIRequest {
  prompt: string;
  subject?: Subject;
  mode?: SolverMode | QuizDifficulty;
  imageUrl?: string;
  context?: string;
}

export interface AIResponse {
  content: string;
  success: boolean;
  error?: string;
  tokensUsed?: number;
}
