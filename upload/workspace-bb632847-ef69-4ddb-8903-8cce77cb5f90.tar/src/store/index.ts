import { create } from "zustand";
import type {
  PageId,
  Subject,
  SolverMode,
  SolverResult,
  Quiz,
  QuizQuestion,
  QuizDifficulty,
  QuestionType,
  Note,
  ChatMessage,
  ClassroomRoom,
  ClassroomMessage,
  ClassroomAnnouncement,
  ClassroomMember,
  SubjectProgress,
  Achievement,
  DailyStreak,
  UserProfile,
} from "@/types";

// ==========================================
// Navigation Store
// ==========================================
interface NavState {
  currentPage: PageId;
  sidebarOpen: boolean;
  setPage: (page: PageId) => void;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
}

export const useNavStore = create<NavState>((set) => ({
  currentPage: "dashboard",
  sidebarOpen: false,
  setPage: (page) => set({ currentPage: page }),
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
}));

// ==========================================
// Solver Store
// ==========================================
interface SolverState {
  subject: Subject;
  mode: SolverMode;
  query: string;
  imageUrl: string | null;
  isSolving: boolean;
  result: SolverResult | null;
  history: SolverResult[];
  setSubject: (subject: Subject) => void;
  setMode: (mode: SolverMode) => void;
  setQuery: (query: string) => void;
  setImageUrl: (url: string | null) => void;
  setIsSolving: (val: boolean) => void;
  setResult: (result: SolverResult | null) => void;
  addToHistory: (result: SolverResult) => void;
  clearHistory: () => void;
}

export const useSolverStore = create<SolverState>((set) => ({
  subject: "math",
  mode: "normal",
  query: "",
  imageUrl: null,
  isSolving: false,
  result: null,
  history: [],
  setSubject: (subject) => set({ subject }),
  setMode: (mode) => set({ mode }),
  setQuery: (query) => set({ query }),
  setImageUrl: (imageUrl) => set({ imageUrl }),
  setIsSolving: (isSolving) => set({ isSolving }),
  setResult: (result) => set({ result }),
  addToHistory: (result) =>
    set((s) => ({ history: [result, ...s.history].slice(0, 50) })),
  clearHistory: () => set({ history: [] }),
}));

// ==========================================
// Quiz Store
// ==========================================
interface QuizState {
  subject: Subject;
  difficulty: QuizDifficulty;
  questionType: QuestionType;
  topic: string;
  questionCount: number;
  isGenerating: boolean;
  currentQuiz: Quiz | null;
  currentQuestionIndex: number;
  answers: Record<string, string>;
  showResults: boolean;
  setSubject: (subject: Subject) => void;
  setDifficulty: (d: QuizDifficulty) => void;
  setQuestionType: (qt: QuestionType) => void;
  setTopic: (topic: string) => void;
  setQuestionCount: (n: number) => void;
  setIsGenerating: (val: boolean) => void;
  setCurrentQuiz: (quiz: Quiz | null) => void;
  setAnswer: (questionId: string, answer: string) => void;
  nextQuestion: () => void;
  prevQuestion: () => void;
  setShowResults: (val: boolean) => void;
  resetQuiz: () => void;
}

export const useQuizStore = create<QuizState>((set) => ({
  subject: "math",
  difficulty: "medium",
  questionType: "mcq",
  topic: "",
  questionCount: 5,
  isGenerating: false,
  currentQuiz: null,
  currentQuestionIndex: 0,
  answers: {},
  showResults: false,
  setSubject: (subject) => set({ subject }),
  setDifficulty: (difficulty) => set({ difficulty }),
  setQuestionType: (questionType) => set({ questionType }),
  setTopic: (topic) => set({ topic }),
  setQuestionCount: (questionCount) => set({ questionCount }),
  setIsGenerating: (isGenerating) => set({ isGenerating }),
  setCurrentQuiz: (currentQuiz) =>
    set({ currentQuiz, currentQuestionIndex: 0, answers: {}, showResults: false }),
  setAnswer: (questionId, answer) =>
    set((s) => ({ answers: { ...s.answers, [questionId]: answer } })),
  nextQuestion: () =>
    set((s) => ({
      currentQuestionIndex: Math.min(
        s.currentQuestionIndex + 1,
        (s.currentQuiz?.questions.length ?? 1) - 1
      ),
    })),
  prevQuestion: () =>
    set((s) => ({
      currentQuestionIndex: Math.max(s.currentQuestionIndex - 1, 0),
    })),
  setShowResults: (showResults) => set({ showResults }),
  resetQuiz: () =>
    set({
      currentQuiz: null,
      currentQuestionIndex: 0,
      answers: {},
      showResults: false,
      isGenerating: false,
    }),
}));

// ==========================================
// Notebook Store
// ==========================================
interface NotebookState {
  notes: Note[];
  activeNote: Note | null;
  chatMessages: ChatMessage[];
  isUploading: boolean;
  isSummarizing: boolean;
  isChatting: boolean;
  searchQuery: string;
  setNotes: (notes: Note[]) => void;
  addNote: (note: Note) => void;
  updateNote: (id: string, updates: Partial<Note>) => void;
  deleteNote: (id: string) => void;
  setActiveNote: (note: Note | null) => void;
  addChatMessage: (msg: ChatMessage) => void;
  clearChat: () => void;
  setIsUploading: (val: boolean) => void;
  setIsSummarizing: (val: boolean) => void;
  setIsChatting: (val: boolean) => void;
  setSearchQuery: (q: string) => void;
}

export const useNotebookStore = create<NotebookState>((set) => ({
  notes: [],
  activeNote: null,
  chatMessages: [],
  isUploading: false,
  isSummarizing: false,
  isChatting: false,
  searchQuery: "",
  setNotes: (notes) => set({ notes }),
  addNote: (note) => set((s) => ({ notes: [note, ...s.notes] })),
  updateNote: (id, updates) =>
    set((s) => ({
      notes: s.notes.map((n) => (n.id === id ? { ...n, ...updates } : n)),
      activeNote:
        s.activeNote?.id === id ? { ...s.activeNote, ...updates } : s.activeNote,
    })),
  deleteNote: (id) =>
    set((s) => ({
      notes: s.notes.filter((n) => n.id !== id),
      activeNote: s.activeNote?.id === id ? null : s.activeNote,
    })),
  setActiveNote: (activeNote) => set({ activeNote, chatMessages: [] }),
  addChatMessage: (msg) =>
    set((s) => ({ chatMessages: [...s.chatMessages, msg] })),
  clearChat: () => set({ chatMessages: [] }),
  setIsUploading: (isUploading) => set({ isUploading }),
  setIsSummarizing: (isSummarizing) => set({ isSummarizing }),
  setIsChatting: (isChatting) => set({ isChatting }),
  setSearchQuery: (searchQuery) => set({ searchQuery }),
}));

// ==========================================
// Classroom Store
// ==========================================
interface ClassroomState {
  currentRoom: ClassroomRoom | null;
  rooms: ClassroomRoom[];
  messages: ClassroomMessage[];
  members: ClassroomMember[];
  announcements: ClassroomAnnouncement[];
  isCreating: boolean;
  isJoining: boolean;
  roomCode: string;
  roomName: string;
  roomSubject: Subject;
  newMessage: string;
  showMembers: boolean;
  setCurrentRoom: (room: ClassroomRoom | null) => void;
  setRooms: (rooms: ClassroomRoom[]) => void;
  addRoom: (room: ClassroomRoom) => void;
  setMessages: (messages: ClassroomMessage[]) => void;
  addMessage: (message: ClassroomMessage) => void;
  setMembers: (members: ClassroomMember[]) => void;
  setAnnouncements: (announcements: ClassroomAnnouncement[]) => void;
  addAnnouncement: (a: ClassroomAnnouncement) => void;
  setIsCreating: (val: boolean) => void;
  setIsJoining: (val: boolean) => void;
  setRoomCode: (code: string) => void;
  setRoomName: (name: string) => void;
  setRoomSubject: (subject: Subject) => void;
  setNewMessage: (msg: string) => void;
  setShowMembers: (val: boolean) => void;
  leaveRoom: () => void;
}

export const useClassroomStore = create<ClassroomState>((set) => ({
  currentRoom: null,
  rooms: [],
  messages: [],
  members: [],
  announcements: [],
  isCreating: false,
  isJoining: false,
  roomCode: "",
  roomName: "",
  roomSubject: "math",
  newMessage: "",
  showMembers: false,
  setCurrentRoom: (currentRoom) =>
    set({ currentRoom, messages: [], members: [], announcements: [] }),
  setRooms: (rooms) => set({ rooms }),
  addRoom: (room) => set((s) => ({ rooms: [...s.rooms, room] })),
  setMessages: (messages) => set({ messages }),
  addMessage: (message) =>
    set((s) => ({ messages: [...s.messages, message] })),
  setMembers: (members) => set({ members }),
  setAnnouncements: (announcements) => set({ announcements }),
  addAnnouncement: (a) =>
    set((s) => ({ announcements: [a, ...s.announcements] })),
  setIsCreating: (isCreating) => set({ isCreating }),
  setIsJoining: (isJoining) => set({ isJoining }),
  setRoomCode: (roomCode) => set({ roomCode }),
  setRoomName: (roomName) => set({ roomName }),
  setRoomSubject: (roomSubject) => set({ roomSubject }),
  setNewMessage: (newMessage) => set({ newMessage }),
  setShowMembers: (showMembers) => set({ showMembers }),
  leaveRoom: () =>
    set({
      currentRoom: null,
      messages: [],
      members: [],
      announcements: [],
      newMessage: "",
    }),
}));

// ==========================================
// Progress Store
// ==========================================
interface ProgressState {
  subjectProgress: SubjectProgress[];
  achievements: Achievement[];
  streak: DailyStreak;
  totalQuizzes: number;
  totalQuestions: number;
  isLoading: boolean;
  setSubjectProgress: (sp: SubjectProgress[]) => void;
  setAchievements: (a: Achievement[]) => void;
  setStreak: (s: DailyStreak) => void;
  setTotalQuizzes: (n: number) => void;
  setTotalQuestions: (n: number) => void;
  setIsLoading: (val: boolean) => void;
}

export const useProgressStore = create<ProgressState>((set) => ({
  subjectProgress: [
    { subject: "math", score: 72, quizzesTaken: 5, questionsAttempted: 40, correctAnswers: 29, streak: 3, lastPracticed: Date.now() },
    { subject: "science", score: 85, quizzesTaken: 7, questionsAttempted: 56, correctAnswers: 48, streak: 5, lastPracticed: Date.now() },
    { subject: "sanskrit", score: 60, quizzesTaken: 3, questionsAttempted: 24, correctAnswers: 14, streak: 1, lastPracticed: Date.now() - 86400000 },
    { subject: "sst", score: 78, quizzesTaken: 4, questionsAttempted: 32, correctAnswers: 25, streak: 2, lastPracticed: Date.now() },
  ],
  achievements: [
    { id: "first-quiz", title: "First Quiz", description: "Complete your first quiz", icon: "🏆", progress: 1, maxProgress: 1, unlockedAt: Date.now() - 86400000 * 5 },
    { id: "streak-3", title: "3-Day Streak", description: "Study 3 days in a row", icon: "🔥", progress: 3, maxProgress: 3, unlockedAt: Date.now() - 86400000 * 2 },
    { id: "streak-7", title: "7-Day Streak", description: "Study 7 days in a row", icon: "⚡", progress: 3, maxProgress: 7 },
    { id: "quiz-master", title: "Quiz Master", description: "Score 100% on 5 quizzes", icon: "🎯", progress: 2, maxProgress: 5 },
    { id: "explorer", title: "Explorer", description: "Try all 4 subjects", icon: "🌍", progress: 4, maxProgress: 4, unlockedAt: Date.now() - 86400000 },
  ],
  streak: { current: 3, longest: 7, lastActiveDate: new Date().toISOString().split("T")[0] },
  totalQuizzes: 19,
  totalQuestions: 152,
  isLoading: false,
  setSubjectProgress: (subjectProgress) => set({ subjectProgress }),
  setAchievements: (achievements) => set({ achievements }),
  setStreak: (streak) => set({ streak }),
  setTotalQuizzes: (totalQuizzes) => set({ totalQuizzes }),
  setTotalQuestions: (totalQuestions) => set({ totalQuestions }),
  setIsLoading: (isLoading) => set({ isLoading }),
}));

// ==========================================
// User Store
// ==========================================
interface UserState {
  profile: UserProfile;
  isDemoMode: boolean;
  setProfile: (profile: UserProfile) => void;
  updateProfile: (updates: Partial<UserProfile>) => void;
  setIsDemoMode: (val: boolean) => void;
}

export const useUserStore = create<UserState>((set) => ({
  profile: {
    id: "demo-user",
    name: "Student",
    classLevel: 10,
    subjects: ["math", "science", "sanskrit", "sst"],
    createdAt: Date.now(),
  },
  isDemoMode: true,
  setProfile: (profile) => set({ profile }),
  updateProfile: (updates) =>
    set((s) => ({ profile: { ...s.profile, ...updates } })),
  setIsDemoMode: (isDemoMode) => set({ isDemoMode }),
}));
