// ==========================================
// MongoDB Connection with Graceful Fallback
// ==========================================

import mongoose from "mongoose";

const MONGODB_URI = process.env.MONGODB_URI || "";

interface MongooseCache {
  conn: typeof mongoose | null;
  promise: Promise<typeof mongoose> | null;
}

declare global {
  var mongoose: MongooseCache | undefined;
}

let cached: MongooseCache = global.mongoose || { conn: null, promise: null };

if (!global.mongoose) {
  global.mongoose = cached;
}

export async function connectDB(): Promise<typeof mongoose | null> {
  if (!MONGODB_URI) {
    console.log("📦 MongoDB URI not set — running in demo mode (no DB)");
    return null;
  }

  if (cached.conn) {
    return cached.conn;
  }

  if (!cached.promise) {
    const opts = {
      bufferCommands: false,
      serverSelectionTimeoutMS: 5000,
      connectTimeoutMS: 5000,
    };

    cached.promise = mongoose
      .connect(MONGODB_URI, opts)
      .then((mongoose) => {
        console.log("📦 MongoDB connected successfully");
        return mongoose;
      })
      .catch((err) => {
        console.warn("⚠️ MongoDB connection failed:", err.message);
        cached.promise = null;
        return null as unknown as typeof mongoose;
      });
  }

  try {
    cached.conn = await cached.promise;
  } catch {
    cached.conn = null;
    cached.promise = null;
  }

  return cached.conn;
}

export async function isDBConnected(): Promise<boolean> {
  try {
    const conn = await connectDB();
    return conn !== null;
  } catch {
    return false;
  }
}
