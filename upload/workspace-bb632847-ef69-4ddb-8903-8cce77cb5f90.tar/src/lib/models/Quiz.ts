// ==========================================
// Quiz Model
// ==========================================

import mongoose, { Schema, type Document } from "mongoose";

export interface IQuiz extends Document {
  userId: string;
  title: string;
  subject: string;
  difficulty: string;
  questions: Record<string, unknown>[];
  score: number;
  totalQuestions: number;
  completedAt?: Date;
  createdAt: Date;
}

const QuizSchema = new Schema<IQuiz>(
  {
    userId: { type: String, required: true, index: true },
    title: { type: String, required: true },
    subject: { type: String, required: true },
    difficulty: { type: String, default: "medium" },
    questions: { type: [], default: [] },
    score: { type: Number, default: 0 },
    totalQuestions: { type: Number, default: 0 },
    completedAt: { type: Date },
  },
  { timestamps: true }
);

export const Quiz =
  mongoose.models.Quiz || mongoose.model<IQuiz>("Quiz", QuizSchema);
