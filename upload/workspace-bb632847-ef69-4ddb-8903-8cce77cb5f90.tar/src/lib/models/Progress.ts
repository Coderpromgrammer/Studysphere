// ==========================================
// Progress Model
// ==========================================

import mongoose, { Schema, type Document } from "mongoose";

export interface IProgress extends Document {
  userId: string;
  subject: string;
  quizzesTaken: number;
  questionsAttempted: number;
  correctAnswers: number;
  streak: number;
  lastPracticed: Date;
  createdAt: Date;
}

const ProgressSchema = new Schema<IProgress>(
  {
    userId: { type: String, required: true, index: true },
    subject: { type: String, required: true },
    quizzesTaken: { type: Number, default: 0 },
    questionsAttempted: { type: Number, default: 0 },
    correctAnswers: { type: Number, default: 0 },
    streak: { type: Number, default: 0 },
    lastPracticed: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

// Compound index for userId + subject
ProgressSchema.index({ userId: 1, subject: 1 }, { unique: true });

export const Progress =
  mongoose.models.Progress || mongoose.model<IProgress>("Progress", ProgressSchema);
