// ==========================================
// Room (Classroom) Model
// ==========================================

import mongoose, { Schema, type Document } from "mongoose";

export interface IRoom extends Document {
  name: string;
  code: string;
  subject: string;
  createdBy: string;
  members: Array<{
    id: string;
    name: string;
    role: string;
    joinedAt: Date;
  }>;
  isActive: boolean;
  createdAt: Date;
}

const RoomSchema = new Schema<IRoom>(
  {
    name: { type: String, required: true },
    code: { type: String, required: true, unique: true },
    subject: { type: String, default: "math" },
    createdBy: { type: String, required: true },
    members: { type: [], default: [] },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const Room =
  mongoose.models.Room || mongoose.model<IRoom>("Room", RoomSchema);
