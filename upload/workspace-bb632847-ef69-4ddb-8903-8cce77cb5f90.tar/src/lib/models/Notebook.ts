// ==========================================
// Notebook Model
// ==========================================

import mongoose, { Schema, type Document } from "mongoose";

export interface INotebook extends Document {
  userId: string;
  title: string;
  content: string;
  summary: string;
  keyPoints: string[];
  subject?: string;
  tags: string[];
  isAIGenerated: boolean;
  sourceType: "text" | "file" | "photo" | "quick";
  fileName?: string;
  imageUrl?: string;
  createdAt: Date;
  updatedAt: Date;
}

const NotebookSchema = new Schema<INotebook>(
  {
    userId: { type: String, required: true, index: true },
    title: { type: String, required: true },
    content: { type: String, default: "" },
    summary: { type: String, default: "" },
    keyPoints: { type: [String], default: [] },
    subject: { type: String },
    tags: { type: [String], default: [] },
    isAIGenerated: { type: Boolean, default: false },
    sourceType: { type: String, enum: ["text", "file", "photo", "quick"], default: "text" },
    fileName: { type: String },
    imageUrl: { type: String },
  },
  { timestamps: true }
);

export const Notebook =
  mongoose.models.Notebook || mongoose.model<INotebook>("Notebook", NotebookSchema);
