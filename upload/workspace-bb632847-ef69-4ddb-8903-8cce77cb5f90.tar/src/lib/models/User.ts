// ==========================================
// User Model
// ==========================================

import mongoose, { Schema, type Document } from "mongoose";

export interface IUser extends Document {
  clerkId: string;
  name: string;
  email?: string;
  avatar?: string;
  classLevel: number;
  school?: string;
  subjects: string[];
  createdAt: Date;
  updatedAt: Date;
}

const UserSchema = new Schema<IUser>(
  {
    clerkId: { type: String, required: true, unique: true },
    name: { type: String, required: true },
    email: { type: String },
    avatar: { type: String },
    classLevel: { type: Number, default: 10 },
    school: { type: String },
    subjects: { type: [String], default: ["math", "science", "sanskrit", "sst"] },
  },
  { timestamps: true }
);

export const User =
  mongoose.models.User || mongoose.model<IUser>("User", UserSchema);
