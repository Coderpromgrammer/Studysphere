// ==========================================
// Flashcard Model
// ==========================================

import mongoose, { Schema, type Document } from "mongoose";

export interface IFlashcard extends Document {
  userId: string;
  subject: string;
  front: string;
  back: string;
  difficulty: string;
  nextReview: Date;
  reviewCount: number;
  createdAt: Date;
}

const FlashcardSchema = new Schema<IFlashcard>(
  {
    userId: { type: String, required: true, index: true },
    subject: { type: String, required: true },
    front: { type: String, required: true },
    back: { type: String, required: true },
    difficulty: { type: String, default: "medium" },
    nextReview: { type: Date, default: Date.now },
    reviewCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export const Flashcard =
  mongoose.models.Flashcard || mongoose.model<IFlashcard>("Flashcard", FlashcardSchema);
