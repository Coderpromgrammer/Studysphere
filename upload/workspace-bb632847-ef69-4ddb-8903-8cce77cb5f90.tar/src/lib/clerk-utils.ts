// ==========================================
// Clerk Utilities — Safe re-exports
// ==========================================

// Re-export Clerk utilities safely
// If Clerk is not configured, these will return safe defaults

export function isClerkConfigured(): boolean {
  return !!(process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY);
}

export function getClerkPublishableKey(): string | undefined {
  return process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY || undefined;
}
