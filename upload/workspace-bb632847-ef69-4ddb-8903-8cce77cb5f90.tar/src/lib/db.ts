// Database client — Safe fallback wrapper
// This project uses Mongoose (MongoDB). This file provides a safe
// fallback for any code that might import from @/lib/db.

export const db = null;

export async function initDb() {
  // Mongoose is used via @/lib/mongodb instead
  return null;
}
