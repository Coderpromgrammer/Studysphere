"use client";

// ==========================================
// Clerk Component Utilities — Safe wrappers
// ==========================================

export { isClerkConfigured, getClerkPublishableKey } from "./clerk-utils";
