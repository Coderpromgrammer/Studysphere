// ==========================================
// AI Prompt Templates
// ==========================================

import type { Subject, SolverMode, QuizDifficulty, QuestionType } from "@/types";

const SUBJECT_NAMES: Record<Subject, string> = {
  math: "Mathematics",
  science: "Science",
  sanskrit: "Sanskrit",
  sst: "Social Studies",
};

const MODE_INSTRUCTIONS: Record<SolverMode, string> = {
  easy: "Explain in very simple terms, like explaining to a beginner. Use basic language and simple examples.",
  normal: "Provide a clear, well-structured explanation suitable for a high school student.",
  exam: "Provide an exam-ready answer with proper formatting, step-by-step working, and key points highlighted. Be thorough and precise.",
};

export function buildSolvePrompt(
  query: string,
  subject: Subject,
  mode: SolverMode,
  hasImage?: boolean
): string {
  const imageNote = hasImage
    ? "\nThe user has also provided an image related to their question. Analyze the image content and incorporate it into your answer."
    : "";

  return `You are an expert ${SUBJECT_NAMES[subject]} tutor for Indian school students (Classes 6-12, CBSE/ICSE board).

${MODE_INSTRUCTIONS[mode]}

Subject: ${SUBJECT_NAMES[subject]}
Mode: ${mode.charAt(0).toUpperCase() + mode.slice(1)}
${imageNote}

Student's Question: ${query}

Instructions:
- Provide a clear, step-by-step solution
- Break down complex problems into smaller steps
- Use proper formatting with numbered steps
- Include relevant formulas or definitions
- End with a brief summary or key takeaway
- If this is a math problem, show all working clearly
- If this is a science question, explain the underlying concepts
- For Sanskrit, provide transliteration and word-by-word meaning where appropriate
- For Social Studies, provide structured answers with key points

Format your response with clear sections using markdown headers (##) for steps.`;
}

export function buildChatPrompt(
  message: string,
  subject?: Subject,
  context?: string
): string {
  const subjectContext = subject
    ? `The student is currently studying ${SUBJECT_NAMES[subject]}.`
    : "The student may ask about any subject.";
  const contextNote = context
    ? `\nAdditional context from the student's notes:\n${context.slice(0, 2000)}`
    : "";

  return `You are a friendly and helpful AI tutor for Indian school students (Classes 6-12).
${subjectContext}${contextNote}

Guidelines:
- Be encouraging and supportive
- Explain concepts in simple, relatable terms
- Use examples that Indian students can relate to
- If the student is wrong, gently correct them with explanation
- Keep responses concise but thorough
- Use emojis sparingly for a friendly tone

Student: ${message}`;
}

export function buildSummarizePrompt(content: string, subject?: Subject): string {
  const subjectContext = subject
    ? ` for ${SUBJECT_NAMES[subject]}`
    : "";

  return `You are an AI study assistant. Summarize the following content into clear, well-organized study notes${subjectContext}.

Instructions:
1. Create a concise summary (2-3 paragraphs)
2. Extract 5-8 key points as bullet points
3. Identify important definitions or formulas
4. Suggest 2-3 study tips for this material

Content to summarize:
${content}

Format your response as JSON with these fields:
{
  "summary": "Your summary here",
  "keyPoints": ["Point 1", "Point 2", ...],
  "definitions": ["Def 1", "Def 2", ...],
  "studyTips": ["Tip 1", "Tip 2", ...]
}`;
}

export function buildQuizPrompt(
  topic: string,
  subject: Subject,
  difficulty: QuizDifficulty,
  questionType: QuestionType,
  count: number
): string {
  const typeInstruction =
    questionType === "mcq"
      ? "multiple choice questions with 4 options each"
      : questionType === "true-false"
        ? "true/false questions"
        : "short answer questions";

  const difficultyInstruction =
    difficulty === "easy"
      ? "easy questions suitable for beginners (Class 6-8 level)"
      : difficulty === "medium"
        ? "moderate difficulty questions (Class 9-10 level)"
        : "challenging questions (Class 11-12 level, competitive exam style)";

  return `Generate ${count} ${typeInstruction} on the topic "${topic}" for ${SUBJECT_NAMES[subject]}.
${difficultyInstruction}

IMPORTANT: Return ONLY valid JSON in this exact format, no extra text:
{
  "questions": [
    {
      "id": "q1",
      "question": "Question text here?",
      "options": ["A) Option 1", "B) Option 2", "C) Option 3", "D) Option 4"],
      "correctAnswer": "A) Option 1",
      "explanation": "Brief explanation of why this is correct",
      "type": "${questionType}",
      "subject": "${subject}",
      "difficulty": "${difficulty}"
    }
  ]
}

For true/false questions, use options: ["True", "False"]
For short-answer questions, omit the options field and put the expected short answer in correctAnswer.

Make sure questions are accurate and appropriate for Indian school curriculum (CBSE/ICSE).`;
}

export function buildTranslatePrompt(
  text: string,
  direction: "to-sanskrit" | "from-sanskrit"
): string {
  const instruction =
    direction === "to-sanskrit"
      ? "Translate the following text from English/Hindi to Sanskrit. Provide both Devanagari script and romanized (IAST) transliteration."
      : "Translate the following Sanskrit text to English. Provide word-by-word meaning and grammatical analysis where helpful.";

  return `You are a Sanskrit language expert for Indian school students.
${instruction}

Text: ${text}

Provide the translation with:
1. Full translation
2. Word-by-word breakdown (where applicable)
3. Grammatical notes (simplified for students)
4. Any cultural or literary context`;
}
