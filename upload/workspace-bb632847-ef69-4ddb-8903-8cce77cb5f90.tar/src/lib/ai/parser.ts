// ==========================================
// AI Response Parser
// ==========================================

import type { QuizQuestion } from "@/types";

/**
 * Parse AI response to extract structured data
 */
export function parseSolveResponse(content: string): {
  answer: string;
  steps: string[];
  explanation: string;
} {
  // Try to extract steps from the response
  const stepRegex = /(?:##?\s*Step\s*\d+|^\d+\.\s)/gm;
  const hasSteps = stepRegex.test(content);

  let steps: string[] = [];
  let answer = content;
  let explanation = "";

  if (hasSteps) {
    // Split by step headers
    const parts = content.split(/(?:##?\s*Step\s*\d+)/i);
    if (parts.length > 1) {
      steps = parts.slice(1).map((s) => s.trim());
      answer = parts[0].trim();
    }

    // Try to extract explanation/summary
    const summaryMatch = content.match(
      /(?:##?\s*(?:Summary|Key Takeaway|Conclusion|Explanation))\s*([\s\S]*?)$/i
    );
    if (summaryMatch) {
      explanation = summaryMatch[1].trim();
    }
  }

  if (!explanation) {
    explanation = "Review the steps above for the complete solution.";
  }

  if (steps.length === 0) {
    // No clear steps found, treat the whole content as the answer
    steps = content.split("\n\n").filter((s) => s.trim().length > 0);
    answer = steps[0] || content;
    steps = steps.slice(1);
  }

  return { answer, steps, explanation };
}

/**
 * Parse quiz generation response into QuizQuestion objects
 */
export function parseQuizResponse(content: string): QuizQuestion[] {
  // Try to extract JSON from the response
  try {
    // First, try direct JSON parse
    const data = JSON.parse(content);
    if (data.questions && Array.isArray(data.questions)) {
      return data.questions.map((q: Record<string, unknown>, i: number) => ({
        id: q.id || `q${i + 1}`,
        question: q.question || "",
        options: Array.isArray(q.options) ? q.options : undefined,
        correctAnswer: q.correctAnswer || "",
        explanation: q.explanation || "",
        type: q.type || "mcq",
        subject: q.subject || "math",
        difficulty: q.difficulty || "medium",
      }));
    }
  } catch {
    // Not direct JSON, try to extract JSON block
  }

  // Try to find JSON block in the response
  const jsonMatch = content.match(/\{[\s\S]*"questions"[\s\S]*\}/);
  if (jsonMatch) {
    try {
      const data = JSON.parse(jsonMatch[0]);
      if (data.questions && Array.isArray(data.questions)) {
        return data.questions.map((q: Record<string, unknown>, i: number) => ({
          id: q.id || `q${i + 1}`,
          question: q.question || "",
          options: Array.isArray(q.options) ? q.options : undefined,
          correctAnswer: q.correctAnswer || "",
          explanation: q.explanation || "",
          type: q.type || "mcq",
          subject: q.subject || "math",
          difficulty: q.difficulty || "medium",
        }));
      }
    } catch {
      // JSON parse failed
    }
  }

  // Fallback: generate simple questions from the text
  return [
    {
      id: "q1",
      question: "AI could not generate structured quiz questions. Please try again with a more specific topic.",
      correctAnswer: "N/A",
      explanation: "The AI response could not be parsed into quiz format.",
      type: "mcq",
      subject: "math",
      difficulty: "medium",
    },
  ];
}

/**
 * Parse summarize response into structured note
 */
export function parseSummarizeResponse(content: string): {
  summary: string;
  keyPoints: string[];
  definitions?: string[];
  studyTips?: string[];
} {
  // Try JSON parse first
  try {
    const data = JSON.parse(content);
    return {
      summary: data.summary || content,
      keyPoints: Array.isArray(data.keyPoints) ? data.keyPoints : [],
      definitions: Array.isArray(data.definitions) ? data.definitions : [],
      studyTips: Array.isArray(data.studyTips) ? data.studyTips : [],
    };
  } catch {
    // Not JSON
  }

  // Try to find JSON block
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    try {
      const data = JSON.parse(jsonMatch[0]);
      return {
        summary: data.summary || content,
        keyPoints: Array.isArray(data.keyPoints) ? data.keyPoints : [],
        definitions: Array.isArray(data.definitions) ? data.definitions : [],
        studyTips: Array.isArray(data.studyTips) ? data.studyTips : [],
      };
    } catch {
      // JSON parse failed
    }
  }

  // Fallback: parse as plain text
  const lines = content.split("\n").filter((l) => l.trim());
  const keyPoints = lines
    .filter((l) => l.match(/^[-•*]\s/) || l.match(/^\d+\.\s/))
    .map((l) => l.replace(/^[-•*]\s/, "").replace(/^\d+\.\s/, "").trim());

  return {
    summary: content.slice(0, 500),
    keyPoints: keyPoints.length > 0 ? keyPoints : ["Review the source material for key points"],
  };
}
