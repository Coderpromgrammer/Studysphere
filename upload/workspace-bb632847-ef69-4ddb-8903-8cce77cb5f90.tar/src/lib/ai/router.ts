// ==========================================
// AI Router — Routes tasks to appropriate AI backend
// ==========================================

import type { Subject, SolverMode, QuizDifficulty } from "@/types";

export type AITask =
  | "solve"
  | "chat"
  | "summarize"
  | "quiz"
  | "translate"
  | "explain";

export interface AITaskConfig {
  task: AITask;
  subject?: Subject;
  mode?: SolverMode | QuizDifficulty;
  maxTokens?: number;
  temperature?: number;
}

const TASK_DEFAULTS: Record<AITask, { maxTokens: number; temperature: number }> = {
  solve: { maxTokens: 4096, temperature: 0.2 },
  chat: { maxTokens: 2048, temperature: 0.5 },
  summarize: { maxTokens: 2048, temperature: 0.3 },
  quiz: { maxTokens: 4096, temperature: 0.4 },
  translate: { maxTokens: 2048, temperature: 0.2 },
  explain: { maxTokens: 2048, temperature: 0.3 },
};

export function getTaskConfig(taskConfig: AITaskConfig): {
  maxTokens: number;
  temperature: number;
} {
  const defaults = TASK_DEFAULTS[taskConfig.task];
  return {
    maxTokens: taskConfig.maxTokens ?? defaults.maxTokens,
    temperature: taskConfig.temperature ?? defaults.temperature,
  };
}
