// Next.js 16 Proxy — Replaces middleware.ts
// This file handles request proxying/middleware in Next.js 16

import type { NextRequest } from "next/server";

export function proxy(request: NextRequest) {
  // No custom proxy logic needed for now
  // Clerk handles its own middleware when configured
  return;
}
