"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useTheme } from "next-themes";
import { useUserStore } from "@/store";
import {
  Settings,
  Moon,
  Sun,
  GraduationCap,
  School,
  User,
  Sparkles,
} from "lucide-react";

const CLASS_LEVELS = [6, 7, 8, 9, 10, 11, 12];

export function SettingsPage() {
  const { theme, setTheme } = useTheme();
  const { profile, updateProfile } = useUserStore();
  const [name, setName] = useState(profile.name);
  const [school, setSchool] = useState(profile.school || "");

  const handleSave = () => {
    updateProfile({ name: name.trim() || "Student", school: school.trim() });
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Settings className="w-6 h-6" />
          Settings
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Customize your StudySphere experience
        </p>
      </div>

      {/* Profile */}
      <Card className="glass-card rounded-2xl">
        <CardContent className="p-5 space-y-4">
          <h3 className="font-semibold flex items-center gap-2">
            <User className="w-4 h-4" />
            Profile
          </h3>
          <div className="space-y-3">
            <div>
              <Label className="text-sm">Name</Label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="glass-input bg-transparent border-0 focus-visible:ring-0 mt-1"
                placeholder="Your name"
              />
            </div>
            <div>
              <Label className="text-sm">School</Label>
              <Input
                value={school}
                onChange={(e) => setSchool(e.target.value)}
                className="glass-input bg-transparent border-0 focus-visible:ring-0 mt-1"
                placeholder="Your school name"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Class Level */}
      <Card className="glass-card rounded-2xl">
        <CardContent className="p-5 space-y-4">
          <h3 className="font-semibold flex items-center gap-2">
            <GraduationCap className="w-4 h-4" />
            Class Level
          </h3>
          <div className="grid grid-cols-4 gap-2">
            {CLASS_LEVELS.map((level) => (
              <button
                key={level}
                onClick={() => updateProfile({ classLevel: level })}
                className={`p-3 rounded-xl text-sm font-medium transition-all ${
                  profile.classLevel === level
                    ? "bg-primary text-primary-foreground"
                    : "glass-button"
                }`}
              >
                Class {level}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Theme */}
      <Card className="glass-card rounded-2xl">
        <CardContent className="p-5 space-y-4">
          <h3 className="font-semibold flex items-center gap-2">
            {theme === "dark" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            Appearance
          </h3>
          <div className="flex items-center justify-between">
            <Label className="text-sm">Dark Mode</Label>
            <Switch
              checked={theme === "dark"}
              onCheckedChange={(checked) => setTheme(checked ? "dark" : "light")}
            />
          </div>
        </CardContent>
      </Card>

      {/* About */}
      <Card className="glass-card rounded-2xl">
        <CardContent className="p-5">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-violet-500" />
            <h3 className="font-semibold">About StudySphere AI</h3>
          </div>
          <p className="text-sm text-muted-foreground">
            An AI-powered learning platform for students (Classes 6-12).
            Features include AI question solving, quiz generation, smart notes,
            collaborative classrooms, and progress tracking.
          </p>
          <p className="text-xs text-muted-foreground mt-2">Version 2.0.0</p>
        </CardContent>
      </Card>

      <Button onClick={handleSave} className="w-full">
        Save Settings
      </Button>
    </div>
  );
}
