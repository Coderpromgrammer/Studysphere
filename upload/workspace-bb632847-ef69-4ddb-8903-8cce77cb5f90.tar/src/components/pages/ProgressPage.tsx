"use client";

import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useProgressStore } from "@/store";
import type { Subject } from "@/types";
import { SUBJECT_CONFIG } from "@/types";
import {
  TrendingUp,
  Flame,
  Trophy,
  Target,
  Calendar,
  Award,
} from "lucide-react";

const SUBJECT_GRADIENTS: Record<Subject, string> = {
  math: "from-amber-400 to-orange-500",
  science: "from-emerald-400 to-teal-500",
  sanskrit: "from-red-400 to-rose-500",
  sst: "from-blue-400 to-indigo-500",
};

export function ProgressPage() {
  const { subjectProgress, achievements, streak, totalQuizzes, totalQuestions } = useProgressStore();
  const unlockedAchievements = achievements.filter((a) => a.unlockedAt);
  const avgScore = Math.round(subjectProgress.reduce((a, b) => a + b.score, 0) / subjectProgress.length);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <TrendingUp className="w-6 h-6 text-emerald-500" />
          Progress Tracker
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Track your learning journey and achievements
        </p>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "Day Streak", value: streak.current, icon: <Flame className="w-5 h-5" />, color: "text-orange-500" },
          { label: "Best Streak", value: streak.longest, icon: <Flame className="w-5 h-5" />, color: "text-red-500" },
          { label: "Quizzes", value: totalQuizzes, icon: <Target className="w-5 h-5" />, color: "text-blue-500" },
          { label: "Avg Score", value: `${avgScore}%`, icon: <Award className="w-5 h-5" />, color: "text-violet-500" },
        ].map((stat, i) => (
          <motion.div key={stat.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <Card className="glass-card rounded-2xl">
              <CardContent className="p-4 text-center">
                <div className={stat.color}>{stat.icon}</div>
                <p className="text-xl font-bold mt-1">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Subject Progress */}
      <div>
        <h2 className="text-lg font-semibold mb-3">Subject Scores</h2>
        <div className="space-y-3">
          {subjectProgress.map((sp, i) => {
            const config = SUBJECT_CONFIG[sp.subject];
            return (
              <motion.div key={sp.subject} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }}>
                <Card className="glass-card rounded-2xl">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${SUBJECT_GRADIENTS[sp.subject]} flex items-center justify-center text-white text-sm`}>
                          {sp.subject === "math" ? "📐" : sp.subject === "science" ? "🔬" : sp.subject === "sanskrit" ? "🕉️" : "🌍"}
                        </div>
                        <div>
                          <p className="text-sm font-semibold">{config.label}</p>
                          <p className="text-xs text-muted-foreground">
                            {sp.quizzesTaken} quizzes • {sp.correctAnswers}/{sp.questionsAttempted} correct
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold">{sp.score}%</p>
                        <div className="flex items-center gap-1">
                          <Flame className="w-3 h-3 text-orange-500" />
                          <span className="text-xs">{sp.streak} day streak</span>
                        </div>
                      </div>
                    </div>
                    <Progress value={sp.score} className="h-2" />
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Achievements */}
      <div>
        <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <Trophy className="w-5 h-5 text-amber-500" />
          Achievements ({unlockedAchievements.length}/{achievements.length})
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {achievements.map((achievement, i) => (
            <motion.div key={achievement.id} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.05 }}>
              <Card className={`glass-card rounded-2xl ${achievement.unlockedAt ? "glass-card-vibrant" : "opacity-60"}`}>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl mb-1">{achievement.icon}</div>
                  <p className="text-sm font-semibold">{achievement.title}</p>
                  <p className="text-xs text-muted-foreground">{achievement.description}</p>
                  {!achievement.unlockedAt && (
                    <div className="mt-2">
                      <Progress value={(achievement.progress / achievement.maxProgress) * 100} className="h-1" />
                      <p className="text-[10px] text-muted-foreground mt-1">
                        {achievement.progress}/{achievement.maxProgress}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Activity Calendar Placeholder */}
      <Card className="glass-card rounded-2xl">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="w-4 h-4 text-violet-500" />
            <h3 className="text-sm font-semibold">Recent Activity</h3>
          </div>
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: 28 }, (_, i) => {
              const isActive = Math.random() > 0.5;
              return (
                <div
                  key={i}
                  className={`w-full aspect-square rounded-sm ${
                    isActive
                      ? "bg-primary/40"
                      : "bg-muted/30"
                  }`}
                />
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
