"use client";

import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { useSolverStore } from "@/store";
import { ModeSelector } from "@/components/shared/ModeSelector";
import { SubjectTag } from "@/components/shared/SubjectTag";
import { ThinkingIndicator } from "@/components/ai/ThinkingIndicator";
import type { Subject, SolverMode, SolverResult } from "@/types";
import {
  Upload,
  Send,
  Copy,
  Check,
  Trash2,
  ImageIcon,
  X,
  Sparkles,
  Lightbulb,
  BookOpen,
} from "lucide-react";

const SUBJECTS: Subject[] = ["math", "science", "sanskrit", "sst"];
const MODES: Array<{ id: SolverMode; label: string; icon: string }> = [
  { id: "easy", label: "Easy", icon: "😊" },
  { id: "normal", label: "Normal", icon: "📝" },
  { id: "exam", label: "Exam", icon: "🎯" },
];

export function SolverPage() {
  const {
    subject,
    mode,
    query,
    imageUrl,
    isSolving,
    result,
    history,
    setSubject,
    setMode,
    setQuery,
    setImageUrl,
    setIsSolving,
    setResult,
    addToHistory,
    clearHistory,
  } = useSolverStore();

  const [copied, setCopied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSolve = async () => {
    if (!query.trim() && !imageUrl) return;
    setIsSolving(true);
    setResult(null);

    try {
      const res = await fetch("/api/ai/solve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: query.trim(),
          subject,
          mode,
          imageUrl: imageUrl || undefined,
        }),
      });

      const data = await res.json();

      if (data.success && data.result) {
        const solverResult: SolverResult = data.result;
        setResult(solverResult);
        addToHistory(solverResult);
      } else {
        setResult({
          answer: data.error || "Failed to get a response. Please try again.",
          steps: [],
          explanation: "",
          subject,
          mode,
          timestamp: Date.now(),
        });
      }
    } catch (err) {
      console.error("Solve error:", err);
      setResult({
        answer: "Network error. Please check your connection and try again.",
        steps: [],
        explanation: "",
        subject,
        mode,
        timestamp: Date.now(),
      });
    } finally {
      setIsSolving(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Convert to base64 data URL for sending to AI
    const reader = new FileReader();
    reader.onloadend = () => {
      setImageUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
      const textarea = document.createElement("textarea");
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const getFullResultText = () => {
    if (!result) return "";
    let text = result.answer;
    if (result.steps.length > 0) {
      text += "\n\nSteps:\n" + result.steps.map((s, i) => `${i + 1}. ${s}`).join("\n");
    }
    if (result.explanation) {
      text += "\n\nExplanation: " + result.explanation;
    }
    return text;
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-violet-500" />
          AI Question Solver
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Ask any question or upload an image — get step-by-step solutions
        </p>
      </div>

      {/* Subject Selector */}
      <div className="flex flex-wrap gap-2">
        {SUBJECTS.map((s) => (
          <SubjectTag
            key={s}
            subject={s}
            active={subject === s}
            onClick={() => setSubject(s)}
          />
        ))}
      </div>

      {/* Mode Selector */}
      <ModeSelector
        modes={MODES}
        activeMode={mode}
        onSelect={(m) => setMode(m as SolverMode)}
      />

      {/* Input Area */}
      <Card className="glass-card rounded-2xl">
        <CardContent className="p-4 space-y-3">
          {/* Text Input */}
          <Textarea
            placeholder="Type your question here... (e.g., 'Solve: 2x + 5 = 15')"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="glass-input min-h-[100px] resize-none bg-transparent border-0 focus-visible:ring-0 p-0 text-sm"
          />

          {/* Image Upload */}
          <div className="space-y-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
            {imageUrl ? (
              <div className="relative inline-block">
                <img
                  src={imageUrl}
                  alt="Uploaded question"
                  className="max-h-32 rounded-xl border border-border/30"
                />
                <button
                  onClick={() => setImageUrl(null)}
                  className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-destructive text-white flex items-center justify-center text-xs"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl glass-button text-sm text-muted-foreground"
              >
                <ImageIcon className="w-4 h-4" />
                Upload Image
              </button>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 pt-2">
            <Button
              onClick={handleSolve}
              disabled={isSolving || (!query.trim() && !imageUrl)}
              className="flex-1 bg-gradient-to-r from-violet-500 to-indigo-500 hover:from-violet-600 hover:to-indigo-600 text-white"
            >
              {isSolving ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Solving...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Solve It
                </>
              )}
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                setQuery("");
                setImageUrl(null);
                setResult(null);
              }}
              className="glass-button"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Thinking Indicator */}
      <AnimatePresence>
        {isSolving && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <Card className="glass-card rounded-2xl">
              <CardContent className="p-0">
                <ThinkingIndicator message="AI is solving your question" />
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Result */}
      <AnimatePresence>
        {result && !isSolving && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <Card className="glass-card-vibrant rounded-2xl">
              <CardContent className="p-5 space-y-4">
                {/* Result Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Lightbulb className="w-5 h-5 text-amber-500" />
                    <h3 className="font-semibold">Solution</h3>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleCopy(getFullResultText())}
                    className="gap-1.5"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-500" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        Copy
                      </>
                    )}
                  </Button>
                </div>

                {/* Answer */}
                <div className="prose prose-sm max-w-none dark:prose-invert">
                  <div className="text-sm leading-relaxed whitespace-pre-wrap">
                    {result.answer}
                  </div>
                </div>

                {/* Steps */}
                {result.steps.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-semibold flex items-center gap-1.5">
                      <BookOpen className="w-4 h-4 text-violet-500" />
                      Step-by-Step
                    </h4>
                    <div className="space-y-2">
                      {result.steps.map((step, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.1 }}
                          className="flex gap-3 p-3 rounded-xl glass-button text-sm"
                        >
                          <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold">
                            {i + 1}
                          </span>
                          <div className="leading-relaxed">{step}</div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Explanation */}
                {result.explanation && (
                  <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-sm">
                    <span className="font-medium text-amber-600 dark:text-amber-400">💡 Key Takeaway: </span>
                    {result.explanation}
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* History */}
      {history.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold">Recent Questions</h2>
            <Button variant="ghost" size="sm" onClick={clearHistory}>
              Clear
            </Button>
          </div>
          <div className="space-y-2 max-h-96 overflow-y-auto touch-scroll">
            {history.slice(0, 10).map((item, i) => (
              <Card key={i} className="glass-card rounded-xl">
                <CardContent className="p-3">
                  <p className="text-sm font-medium line-clamp-1">{item.answer.slice(0, 80)}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="glass-badge text-[10px] py-0 px-2">{item.subject}</span>
                    <span className="glass-badge text-[10px] py-0 px-2">{item.mode}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
