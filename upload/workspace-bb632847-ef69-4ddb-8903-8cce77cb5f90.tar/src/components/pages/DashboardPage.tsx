"use client";

import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavStore } from "@/store";
import { useProgressStore } from "@/store";
import type { PageId, Subject } from "@/types";
import { SUBJECT_CONFIG } from "@/types";
import {
  Brain,
  FileQuestion,
  BookOpen,
  Users,
  TrendingUp,
  Calculator,
  FlaskConical,
  BookMarked,
  Globe,
  Sparkles,
  Flame,
  Zap,
  Trophy,
} from "lucide-react";

const QUICK_ACTIONS: Array<{
  id: PageId;
  label: string;
  icon: React.ReactNode;
  color: string;
}> = [
  { id: "solver", label: "Solve Question", icon: <Brain className="w-5 h-5" />, color: "from-violet-500 to-indigo-500" },
  { id: "quiz", label: "Take a Quiz", icon: <FileQuestion className="w-5 h-5" />, color: "from-amber-500 to-orange-500" },
  { id: "notebook", label: "AI Notes", icon: <BookOpen className="w-5 h-5" />, color: "from-emerald-500 to-teal-500" },
  { id: "classroom", label: "Classroom", icon: <Users className="w-5 h-5" />, color: "from-rose-500 to-pink-500" },
];

const SUBJECT_ICONS: Record<Subject, React.ReactNode> = {
  math: <Calculator className="w-5 h-5" />,
  science: <FlaskConical className="w-5 h-5" />,
  sanskrit: <BookMarked className="w-5 h-5" />,
  sst: <Globe className="w-5 h-5" />,
};

export function DashboardPage() {
  const setPage = useNavStore((s) => s.setPage);
  const { subjectProgress, streak, achievements } = useProgressStore();
  const unlockedAchievements = achievements.filter((a) => a.unlockedAt);

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 17) return "Good Afternoon";
    return "Good Evening";
  };

  return (
    <div className="space-y-6">
      {/* Greeting */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-2xl md:text-3xl font-bold">
          {getGreeting()} 👋
        </h1>
        <p className="text-muted-foreground mt-1">
          Ready to learn something amazing today?
        </p>
      </motion.div>

      {/* Daily Challenge Card */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="glass-card-vibrant rounded-2xl overflow-hidden">
          <CardContent className="p-5">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-indigo-500 flex items-center justify-center flex-shrink-0">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold">Daily Challenge</h3>
                <p className="text-sm text-muted-foreground">
                  Solve 5 questions to keep your streak going!
                </p>
              </div>
              <Button
                onClick={() => setPage("solver")}
                className="bg-gradient-to-r from-violet-500 to-indigo-500 hover:from-violet-600 hover:to-indigo-600 text-white"
              >
                Start
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Streak + Stats */}
      <div className="grid grid-cols-3 gap-3">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <Card className="glass-card rounded-2xl">
            <CardContent className="p-4 text-center">
              <Flame className="w-6 h-6 mx-auto text-orange-500" />
              <p className="text-2xl font-bold mt-1">{streak.current}</p>
              <p className="text-xs text-muted-foreground">Day Streak</p>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card className="glass-card rounded-2xl">
            <CardContent className="p-4 text-center">
              <Trophy className="w-6 h-6 mx-auto text-amber-500" />
              <p className="text-2xl font-bold mt-1">{unlockedAchievements.length}</p>
              <p className="text-xs text-muted-foreground">Achievements</p>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
          <Card className="glass-card rounded-2xl">
            <CardContent className="p-4 text-center">
              <Sparkles className="w-6 h-6 mx-auto text-violet-500" />
              <p className="text-2xl font-bold mt-1">{Math.round(subjectProgress.reduce((a, b) => a + b.score, 0) / subjectProgress.length)}%</p>
              <p className="text-xs text-muted-foreground">Avg Score</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Quick Actions */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
        <h2 className="text-lg font-semibold mb-3">Quick Actions</h2>
        <div className="grid grid-cols-2 gap-3">
          {QUICK_ACTIONS.map((action) => (
            <Card
              key={action.id}
              className="glass-card glass-card-hover rounded-2xl cursor-pointer"
              onClick={() => setPage(action.id)}
            >
              <CardContent className="p-4">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${action.color} flex items-center justify-center text-white mb-2`}>
                  {action.icon}
                </div>
                <p className="text-sm font-medium">{action.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </motion.div>

      {/* Subject Progress */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold">Subject Progress</h2>
          <Button variant="ghost" size="sm" onClick={() => setPage("progress")}>
            <TrendingUp className="w-4 h-4 mr-1" />
            View All
          </Button>
        </div>
        <div className="space-y-2">
          {subjectProgress.map((sp) => {
            const config = SUBJECT_CONFIG[sp.subject];
            return (
              <Card key={sp.subject} className="glass-card rounded-xl">
                <CardContent className="p-3 flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${
                    sp.subject === "math" ? "from-amber-400 to-orange-500" :
                    sp.subject === "science" ? "from-emerald-400 to-teal-500" :
                    sp.subject === "sanskrit" ? "from-red-400 to-rose-500" :
                    "from-blue-400 to-indigo-500"
                  } flex items-center justify-center text-white`}>
                    {SUBJECT_ICONS[sp.subject]}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">{config.label}</p>
                      <p className="text-sm font-semibold">{sp.score}%</p>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-muted mt-1">
                      <div
                        className={`h-full rounded-full ${
                          sp.score >= 80 ? "bg-emerald-500" :
                          sp.score >= 60 ? "bg-amber-500" :
                          "bg-red-500"
                        }`}
                        style={{ width: `${sp.score}%` }}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </motion.div>

      {/* AI Suggestions */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
        <h2 className="text-lg font-semibold mb-3">AI Suggests</h2>
        <Card className="glass-card rounded-2xl">
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-violet-500" />
              <span className="text-sm font-medium">Based on your progress</span>
            </div>
            <div className="space-y-2">
              <button
                onClick={() => setPage("sanskrit-helper")}
                className="w-full text-left p-3 rounded-xl glass-button text-sm"
              >
                🕉️ Practice Sanskrit vocabulary — your lowest subject at 60%
              </button>
              <button
                onClick={() => setPage("quiz")}
                className="w-full text-left p-3 rounded-xl glass-button text-sm"
              >
                🎯 Try a Science quiz — you&apos;re doing great at 85%!
              </button>
              <button
                onClick={() => setPage("math-helper")}
                className="w-full text-left p-3 rounded-xl glass-button text-sm"
              >
                📐 Review Math formulas for upcoming exams
              </button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
