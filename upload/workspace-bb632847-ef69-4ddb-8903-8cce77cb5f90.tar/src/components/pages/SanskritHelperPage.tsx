"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ThinkingIndicator } from "@/components/ai/ThinkingIndicator";
import {
  BookMarked,
  Sparkles,
  Copy,
  Check,
  Lightbulb,
  ArrowRightLeft,
} from "lucide-react";

export function SanskritHelperPage() {
  const [query, setQuery] = useState("");
  const [result, setResult] = useState("");
  const [isSolving, setIsSolving] = useState(false);
  const [copied, setCopied] = useState(false);
  const [translateText, setTranslateText] = useState("");
  const [translateResult, setTranslateResult] = useState("");
  const [isTranslating, setIsTranslating] = useState(false);
  const [translateDir, setTranslateDir] = useState<"from-sanskrit" | "to-sanskrit">("from-sanskrit");

  const handleSolve = async () => {
    if (!query.trim()) return;
    setIsSolving(true);
    setResult("");

    try {
      const res = await fetch("/api/ai/solve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: query.trim(), subject: "sanskrit", mode: "normal" }),
      });
      const data = await res.json();
      setResult(data.result?.answer || data.error || "No response");
    } catch {
      setResult("Failed to get response. Please try again.");
    } finally {
      setIsSolving(false);
    }
  };

  const handleTranslate = async () => {
    if (!translateText.trim()) return;
    setIsTranslating(true);
    setTranslateResult("");

    try {
      const res = await fetch("/api/ai/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: translateText.trim(), direction: translateDir }),
      });
      const data = await res.json();
      setTranslateResult(data.translation || data.error || "No translation");
    } catch {
      setTranslateResult("Translation failed. Please try again.");
    } finally {
      setIsTranslating(false);
    }
  };

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore
    }
  };

  const quickQuestions = [
    "Explain Sandhi in Sanskrit",
    "What is Karaka in Sanskrit grammar?",
    "Translate: विद्या गुरुणा धीयते",
    "Explain Vibhakti system",
    "What are the three Lakaras?",
  ];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <BookMarked className="w-6 h-6 text-red-500" />
          Sanskrit Helper
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Grammar, translations, and Shloka explanations
        </p>
      </div>

      <Tabs defaultValue="ask" className="space-y-4">
        <TabsList className="glass-card">
          <TabsTrigger value="ask">Ask Question</TabsTrigger>
          <TabsTrigger value="translate">Translate</TabsTrigger>
        </TabsList>

        <TabsContent value="ask" className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {quickQuestions.map((q) => (
              <button
                key={q}
                onClick={() => setQuery(q)}
                className="glass-badge text-xs hover:bg-primary/5 cursor-pointer"
              >
                {q.slice(0, 30)}...
              </button>
            ))}
          </div>

          <Card className="glass-card rounded-2xl">
            <CardContent className="p-4 space-y-3">
              <Textarea
                placeholder="Type your Sanskrit question here..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="glass-input min-h-[80px] resize-none bg-transparent border-0 focus-visible:ring-0 p-0"
              />
              <Button
                onClick={handleSolve}
                disabled={isSolving || !query.trim()}
                className="w-full bg-gradient-to-r from-red-500 to-rose-500 hover:from-red-600 hover:to-rose-600 text-white"
              >
                {isSolving ? "Solving..." : <><Sparkles className="w-4 h-4" /> Solve</>}
              </Button>
            </CardContent>
          </Card>

          {isSolving && <ThinkingIndicator message="Analyzing your Sanskrit question" />}

          {result && !isSolving && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
              <Card className="glass-card-vibrant rounded-2xl">
                <CardContent className="p-5">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold flex items-center gap-2">
                      <Lightbulb className="w-4 h-4 text-red-500" />
                      Answer
                    </h3>
                    <Button variant="ghost" size="sm" onClick={() => handleCopy(result)}>
                      {copied ? <><Check className="w-3.5 h-3.5" /> Copied!</> : <><Copy className="w-3.5 h-3.5" /> Copy</>}
                    </Button>
                  </div>
                  <div className="text-sm whitespace-pre-wrap leading-relaxed">{result}</div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </TabsContent>

        <TabsContent value="translate" className="space-y-4">
          <Card className="glass-card rounded-2xl">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center gap-2">
                <Button
                  variant={translateDir === "from-sanskrit" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTranslateDir("from-sanskrit")}
                >
                  Sanskrit → English
                </Button>
                <Button
                  variant={translateDir === "to-sanskrit" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTranslateDir("to-sanskrit")}
                >
                  English → Sanskrit
                </Button>
              </div>
              <Textarea
                placeholder={translateDir === "from-sanskrit" ? "Enter Sanskrit text..." : "Enter English text..."}
                value={translateText}
                onChange={(e) => setTranslateText(e.target.value)}
                className="glass-input min-h-[80px] resize-none bg-transparent border-0 focus-visible:ring-0 p-0"
              />
              <Button
                onClick={handleTranslate}
                disabled={isTranslating || !translateText.trim()}
                className="w-full"
              >
                {isTranslating ? "Translating..." : <><ArrowRightLeft className="w-4 h-4" /> Translate</>}
              </Button>
            </CardContent>
          </Card>

          {isTranslating && <ThinkingIndicator message="Translating" />}

          {translateResult && !isTranslating && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
              <Card className="glass-card-vibrant rounded-2xl">
                <CardContent className="p-5">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold">Translation</h3>
                    <Button variant="ghost" size="sm" onClick={() => handleCopy(translateResult)}>
                      {copied ? <><Check className="w-3.5 h-3.5" /> Copied!</> : <><Copy className="w-3.5 h-3.5" /> Copy</>}
                    </Button>
                  </div>
                  <div className="text-sm whitespace-pre-wrap leading-relaxed">{translateResult}</div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
