"use client";

import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useNotebookStore } from "@/store";
import { ThinkingIndicator } from "@/components/ai/ThinkingIndicator";
import { ChatBubble } from "@/components/ai/ChatBubble";
import type { Note, ChatMessage } from "@/types";
import {
  BookOpen,
  Upload,
  Plus,
  Sparkles,
  Send,
  FileText,
  Image as ImageIcon,
  Trash2,
  Search,
  MessageSquare,
  X,
  FileUp,
} from "lucide-react";

export function NotebookPage() {
  const {
    notes,
    activeNote,
    chatMessages,
    isUploading,
    isSummarizing,
    isChatting,
    searchQuery,
    addNote,
    deleteNote,
    setActiveNote,
    addChatMessage,
    clearChat,
    setIsUploading,
    setIsSummarizing,
    setIsChatting,
    setSearchQuery,
  } = useNotebookStore();

  const [quickNoteTitle, setQuickNoteTitle] = useState("");
  const [quickNoteContent, setQuickNoteContent] = useState("");
  const [quickNoteOpen, setQuickNoteOpen] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [showChat, setShowChat] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredNotes = notes.filter(
    (n) =>
      !searchQuery ||
      n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);

    try {
      let content = "";

      if (file.type.startsWith("image/")) {
        // For images, describe them and send to AI
        const reader = new FileReader();
        const dataUrl = await new Promise<string>((resolve) => {
          const r = new FileReader();
          r.onloadend = () => resolve(r.result as string);
          r.readAsDataURL(file);
        });

        // Summarize the image
        const res = await fetch("/api/ai/summarize", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            content: `[User uploaded an image: ${file.name}. Please analyze and describe this image, extracting any text or educational content visible in it.]`,
          }),
        });

        const data = await res.json();
        content = data.summary || "Image uploaded — content could not be extracted.";

        const note: Note = {
          id: `note-${Date.now()}`,
          title: file.name.replace(/\.[^/.]+$/, ""),
          content: data.summary || "Image note",
          summary: data.summary || "",
          keyPoints: data.keyPoints || [],
          tags: ["image", "upload"],
          isAIGenerated: true,
          sourceType: "photo",
          fileName: file.name,
          imageUrl: dataUrl,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };
        addNote(note);
      } else {
        // Text files
        content = await file.text();

        setIsSummarizing(true);
        const res = await fetch("/api/ai/summarize", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: content.slice(0, 8000) }),
        });

        const data = await res.json();

        const note: Note = {
          id: `note-${Date.now()}`,
          title: file.name.replace(/\.[^/.]+$/, ""),
          content: content.slice(0, 5000),
          summary: data.summary || content.slice(0, 500),
          keyPoints: data.keyPoints || [],
          tags: ["upload", "file"],
          isAIGenerated: true,
          sourceType: "file",
          fileName: file.name,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };
        addNote(note);
      }
    } catch (err) {
      console.error("Upload error:", err);
    } finally {
      setIsUploading(false);
      setIsSummarizing(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleQuickNote = async () => {
    if (!quickNoteTitle.trim() || !quickNoteContent.trim()) return;
    setIsSummarizing(true);

    try {
      const res = await fetch("/api/ai/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: quickNoteContent }),
      });

      const data = await res.json();

      const note: Note = {
        id: `note-${Date.now()}`,
        title: quickNoteTitle.trim(),
        content: quickNoteContent,
        summary: data.summary || quickNoteContent.slice(0, 200),
        keyPoints: data.keyPoints || [],
        tags: ["quick-note"],
        isAIGenerated: true,
        sourceType: "quick",
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      addNote(note);
      setQuickNoteTitle("");
      setQuickNoteContent("");
      setQuickNoteOpen(false);
    } catch (err) {
      console.error("Quick note error:", err);
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleChatSend = async () => {
    if (!chatInput.trim() || !activeNote) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: "user",
      content: chatInput.trim(),
      timestamp: Date.now(),
    };
    addChatMessage(userMsg);
    setChatInput("");
    setIsChatting(true);

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: chatInput.trim(),
          context: activeNote.content,
          subject: activeNote.subject,
        }),
      });

      const data = await res.json();
      const aiMsg: ChatMessage = {
        id: `msg-ai-${Date.now()}`,
        role: "assistant",
        content: data.content || "Sorry, I couldn't process that.",
        timestamp: Date.now(),
      };
      addChatMessage(aiMsg);
    } catch (err) {
      console.error("Chat error:", err);
    } finally {
      setIsChatting(false);
    }
  };

  // If a note is active, show note detail with chat
  if (activeNote) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Button variant="ghost" size="sm" onClick={() => { setActiveNote(null); clearChat(); setShowChat(false); }}>
            <X className="w-4 h-4 mr-1" />
            Back
          </Button>
          <Button variant="outline" size="sm" onClick={() => setShowChat(!showChat)}>
            <MessageSquare className="w-4 h-4 mr-1" />
            {showChat ? "Hide Chat" : "Chat with AI"}
          </Button>
        </div>

        <Card className="glass-card-vibrant rounded-2xl">
          <CardContent className="p-5">
            <h2 className="text-xl font-bold">{activeNote.title}</h2>
            {activeNote.isAIGenerated && (
              <span className="glass-badge text-xs mt-2 inline-flex">
                <Sparkles className="w-3 h-3" />
                AI Generated
              </span>
            )}

            {activeNote.summary && (
              <div className="mt-4 p-3 rounded-xl bg-primary/5 border border-primary/10">
                <h3 className="text-sm font-semibold mb-1">Summary</h3>
                <p className="text-sm text-muted-foreground">{activeNote.summary}</p>
              </div>
            )}

            {activeNote.keyPoints.length > 0 && (
              <div className="mt-3">
                <h3 className="text-sm font-semibold mb-2">Key Points</h3>
                <ul className="space-y-1">
                  {activeNote.keyPoints.map((point, i) => (
                    <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                      <span className="text-primary mt-0.5">•</span>
                      {point}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="mt-4">
              <h3 className="text-sm font-semibold mb-2">Content</h3>
              <div className="text-sm text-muted-foreground whitespace-pre-wrap max-h-64 overflow-y-auto touch-scroll">
                {activeNote.content}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AI Chat */}
        <AnimatePresence>
          {showChat && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              <Card className="glass-card rounded-2xl">
                <CardContent className="p-4 space-y-3">
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-violet-500" />
                    Ask about this note
                  </h3>
                  <div className="max-h-64 overflow-y-auto touch-scroll space-y-2">
                    {chatMessages.map((msg) => (
                      <ChatBubble key={msg.id} role={msg.role} content={msg.content} />
                    ))}
                    {isChatting && <ThinkingIndicator message="AI is thinking" />}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Ask about your note..."
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleChatSend()}
                      className="glass-input bg-transparent border-0 focus-visible:ring-0 text-sm"
                    />
                    <Button
                      size="icon"
                      onClick={handleChatSend}
                      disabled={isChatting || !chatInput.trim()}
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  // Notes List View
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <BookOpen className="w-6 h-6 text-emerald-500" />
          AI Notebook
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Upload files, take notes, and let AI create study materials
        </p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search notes..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="glass-input pl-9 bg-transparent border-0 focus-visible:ring-0"
        />
      </div>

      {/* Upload Area */}
      <Card
        className="glass-card rounded-2xl cursor-pointer"
        onClick={() => fileInputRef.current?.click()}
      >
        <CardContent className="p-6 text-center">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,.txt,.md,.pdf,.doc,.docx"
            onChange={handleFileUpload}
            className="hidden"
          />
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center mx-auto mb-3">
            {isUploading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <FileUp className="w-6 h-6 text-white" />
            )}
          </div>
          <p className="text-sm font-medium">
            {isUploading ? "Processing..." : "Upload File or Photo"}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Drag & drop or click to upload — AI will summarize automatically
          </p>
        </CardContent>
      </Card>

      {/* Quick Note + Notes Grid */}
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Your Notes ({filteredNotes.length})</h2>
        <Dialog open={quickNoteOpen} onOpenChange={setQuickNoteOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1.5">
              <Plus className="w-4 h-4" />
              Quick Note
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-elevated">
            <DialogHeader>
              <DialogTitle>Quick Note</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <Input
                placeholder="Note title..."
                value={quickNoteTitle}
                onChange={(e) => setQuickNoteTitle(e.target.value)}
              />
              <Textarea
                placeholder="Write or paste your notes here..."
                value={quickNoteContent}
                onChange={(e) => setQuickNoteContent(e.target.value)}
                className="min-h-[150px]"
              />
              <Button
                onClick={handleQuickNote}
                disabled={isSummarizing || !quickNoteTitle.trim() || !quickNoteContent.trim()}
                className="w-full"
              >
                {isSummarizing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    AI Processing...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Save & Summarize
                  </>
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {filteredNotes.length === 0 ? (
        <Card className="glass-card rounded-2xl">
          <CardContent className="p-8 text-center">
            <FileText className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
            <p className="text-sm text-muted-foreground">
              No notes yet. Upload a file or create a quick note!
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredNotes.map((note) => (
            <motion.div
              key={note.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card
                className="glass-card glass-card-hover rounded-2xl cursor-pointer"
                onClick={() => setActiveNote(note)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      {note.sourceType === "photo" ? (
                        <ImageIcon className="w-4 h-4 text-emerald-500" />
                      ) : note.sourceType === "file" ? (
                        <FileText className="w-4 h-4 text-blue-500" />
                      ) : (
                        <BookOpen className="w-4 h-4 text-violet-500" />
                      )}
                      <h3 className="text-sm font-semibold line-clamp-1">{note.title}</h3>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-7 h-7 flex-shrink-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteNote(note.id);
                      }}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                  {note.summary && (
                    <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{note.summary}</p>
                  )}
                  <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                    {note.isAIGenerated && (
                      <span className="glass-badge text-[10px] py-0 px-1.5">
                        <Sparkles className="w-2.5 h-2.5" /> AI
                      </span>
                    )}
                    {note.tags.slice(0, 2).map((tag) => (
                      <span key={tag} className="glass-badge text-[10px] py-0 px-1.5">
                        {tag}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
