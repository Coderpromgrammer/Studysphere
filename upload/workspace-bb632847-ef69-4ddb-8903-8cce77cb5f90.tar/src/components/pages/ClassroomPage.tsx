"use client";

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useClassroomStore } from "@/store";
import { SubjectTag } from "@/components/shared/SubjectTag";
import { ThinkingIndicator } from "@/components/ai/ThinkingIndicator";
import type { Subject, ClassroomRoom, ClassroomMessage } from "@/types";
import {
  Users,
  Plus,
  LogIn,
  Send,
  Sparkles,
  Megaphone,
  UserPlus,
  ArrowLeft,
  X,
  Bot,
} from "lucide-react";

const SUBJECTS: Subject[] = ["math", "science", "sanskrit", "sst"];

export function ClassroomPage() {
  const {
    currentRoom,
    messages,
    members,
    isCreating,
    isJoining,
    roomCode,
    roomName,
    roomSubject,
    newMessage,
    showMembers,
    setCurrentRoom,
    addMessage,
    setMembers,
    setIsCreating,
    setIsJoining,
    setRoomCode,
    setRoomName,
    setRoomSubject,
    setNewMessage,
    setShowMembers,
    leaveRoom,
  } = useClassroomStore();

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [announcementText, setAnnouncementText] = useState("");
  const [showAnnouncementInput, setShowAnnouncementInput] = useState(false);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleCreateRoom = async () => {
    if (!roomName.trim()) return;
    setIsCreating(true);

    try {
      const res = await fetch("/api/classroom/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: roomName.trim(),
          subject: roomSubject,
        }),
      });

      const data = await res.json();
      if (data.room) {
        setCurrentRoom(data.room as ClassroomRoom);
        setMembers(data.room.members || []);
        setRoomName("");
      }
    } catch (err) {
      console.error("Create room error:", err);
    } finally {
      setIsCreating(false);
    }
  };

  const handleJoinRoom = async () => {
    if (!roomCode.trim()) return;
    setIsJoining(true);

    try {
      const res = await fetch("/api/classroom/join", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: roomCode.trim().toUpperCase(),
        }),
      });

      const data = await res.json();
      if (data.room) {
        setCurrentRoom(data.room as ClassroomRoom);
        setMembers(data.room.members || []);
        setRoomCode("");
      }
    } catch (err) {
      console.error("Join room error:", err);
    } finally {
      setIsJoining(false);
    }
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !currentRoom) return;

    const msg: ClassroomMessage = {
      id: `msg-${Date.now()}`,
      roomId: currentRoom.id,
      senderId: "demo-user",
      senderName: "You",
      content: newMessage.trim(),
      isAI: false,
      timestamp: Date.now(),
    };

    addMessage(msg);
    setNewMessage("");

    // If question, get AI response
    if (newMessage.trim().endsWith("?")) {
      try {
        const res = await fetch("/api/classroom/messages", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            roomId: currentRoom.id,
            senderId: "demo-user",
            senderName: "You",
            content: newMessage.trim(),
          }),
        });

        const data = await res.json();
        if (data.aiMessage) {
          addMessage(data.aiMessage as ClassroomMessage);
        }
      } catch (err) {
        console.error("Send message error:", err);
      }
    }
  };

  // Inside a room
  if (currentRoom) {
    return (
      <div className="space-y-4 flex flex-col h-[calc(100vh-12rem)]">
        {/* Room Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={leaveRoom}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h2 className="font-semibold">{currentRoom.name}</h2>
              <p className="text-xs text-muted-foreground">
                Code: {currentRoom.code} • {members.length} member{members.length !== 1 ? "s" : ""}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setShowAnnouncementInput(!showAnnouncementInput)}>
              <Megaphone className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setShowMembers(!showMembers)}>
              <Users className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Announcement Input */}
        <AnimatePresence>
          {showAnnouncementInput && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
            >
              <Card className="glass-card rounded-xl">
                <CardContent className="p-3 flex gap-2">
                  <Input
                    placeholder="Post an announcement..."
                    value={announcementText}
                    onChange={(e) => setAnnouncementText(e.target.value)}
                    className="glass-input bg-transparent border-0 focus-visible:ring-0 text-sm"
                  />
                  <Button
                    size="sm"
                    onClick={() => {
                      if (announcementText.trim()) {
                        addMessage({
                          id: `ann-${Date.now()}`,
                          roomId: currentRoom.id,
                          senderId: "demo-user",
                          senderName: "📢 Announcement",
                          content: announcementText.trim(),
                          isAI: false,
                          timestamp: Date.now(),
                        });
                        setAnnouncementText("");
                        setShowAnnouncementInput(false);
                      }
                    }}
                  >
                    Post
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Members Panel */}
        <AnimatePresence>
          {showMembers && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
            >
              <Card className="glass-card rounded-xl">
                <CardContent className="p-3">
                  <h3 className="text-sm font-semibold mb-2">Members</h3>
                  <div className="space-y-2">
                    {members.map((member) => (
                      <div key={member.id} className="flex items-center gap-2 text-sm">
                        <div className={`w-2 h-2 rounded-full ${member.isOnline ? "bg-emerald-500" : "bg-gray-400"}`} />
                        <span>{member.name}</span>
                        <span className="text-xs text-muted-foreground">({member.role})</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Messages */}
        <Card className="glass-card rounded-2xl flex-1 flex flex-col overflow-hidden">
          <CardContent className="p-4 flex-1 overflow-y-auto touch-scroll space-y-3">
            {messages.length === 0 && (
              <div className="text-center text-sm text-muted-foreground py-8">
                <Sparkles className="w-8 h-8 mx-auto mb-2 text-violet-500" />
                <p>Welcome to {currentRoom.name}!</p>
                <p className="text-xs mt-1">Ask a question ending with &quot;?&quot; to get AI help</p>
              </div>
            )}
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.senderId === "demo-user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${
                    msg.isAI
                      ? "bg-gradient-to-br from-violet-500/10 to-indigo-500/10 border border-violet-500/20"
                      : msg.senderId === "demo-user"
                        ? "bg-primary text-primary-foreground"
                        : msg.senderName.includes("Announcement")
                          ? "bg-amber-500/10 border border-amber-500/20"
                          : "glass-card"
                  }`}
                >
                  {msg.senderId !== "demo-user" && (
                    <p className={`text-xs font-semibold mb-1 flex items-center gap-1 ${
                      msg.isAI ? "text-violet-600 dark:text-violet-400" : "text-muted-foreground"
                    }`}>
                      {msg.isAI && <Bot className="w-3 h-3" />}
                      {msg.senderName}
                    </p>
                  )}
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </CardContent>

          {/* Message Input */}
          <div className="p-3 border-t border-border/30">
            <div className="flex gap-2">
              <Input
                placeholder="Type a message... (end with ? for AI help)"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                className="glass-input bg-transparent border-0 focus-visible:ring-0 text-sm"
              />
              <Button
                size="icon"
                onClick={handleSendMessage}
                disabled={!newMessage.trim()}
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  // Room Selection View
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Users className="w-6 h-6 text-rose-500" />
          Classroom
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Create or join a study room with AI-powered help
        </p>
      </div>

      {/* Create Room */}
      <Card className="glass-card rounded-2xl">
        <CardContent className="p-5 space-y-3">
          <h3 className="font-semibold flex items-center gap-2">
            <Plus className="w-4 h-4 text-emerald-500" />
            Create a Room
          </h3>
          <Input
            placeholder="Room name (e.g., Math Study Group)"
            value={roomName}
            onChange={(e) => setRoomName(e.target.value)}
            className="glass-input bg-transparent border-0 focus-visible:ring-0"
          />
          <div className="flex flex-wrap gap-2">
            {SUBJECTS.map((s) => (
              <SubjectTag
                key={s}
                subject={s}
                active={roomSubject === s}
                onClick={() => setRoomSubject(s)}
                size="sm"
              />
            ))}
          </div>
          <Button
            onClick={handleCreateRoom}
            disabled={isCreating || !roomName.trim()}
            className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white"
          >
            {isCreating ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Creating...
              </>
            ) : (
              <>
                <Plus className="w-4 h-4" />
                Create Room
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Join Room */}
      <Card className="glass-card rounded-2xl">
        <CardContent className="p-5 space-y-3">
          <h3 className="font-semibold flex items-center gap-2">
            <UserPlus className="w-4 h-4 text-blue-500" />
            Join a Room
          </h3>
          <Input
            placeholder="Enter room code (e.g., ABC123)"
            value={roomCode}
            onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
            className="glass-input bg-transparent border-0 focus-visible:ring-0"
            maxLength={6}
          />
          <Button
            onClick={handleJoinRoom}
            disabled={isJoining || !roomCode.trim()}
            className="w-full"
            variant="outline"
          >
            {isJoining ? (
              <>
                <div className="w-4 h-4 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
                Joining...
              </>
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                Join Room
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Info Card */}
      <Card className="glass-card rounded-2xl">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-violet-500" />
            <h3 className="text-sm font-semibold">AI-Powered Classroom</h3>
          </div>
          <ul className="text-xs text-muted-foreground space-y-1">
            <li>• Ask questions ending with &quot;?&quot; to get AI responses</li>
            <li>• Post announcements for the whole class</li>
            <li>• Share the room code with classmates</li>
            <li>• Get instant help from the AI tutor</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
