"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ThinkingIndicator } from "@/components/ai/ThinkingIndicator";
import {
  Globe,
  Sparkles,
  Copy,
  Check,
  Lightbulb,
} from "lucide-react";

export function SSTHelperPage() {
  const [query, setQuery] = useState("");
  const [result, setResult] = useState("");
  const [isSolving, setIsSolving] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSolve = async () => {
    if (!query.trim()) return;
    setIsSolving(true);
    setResult("");

    try {
      const res = await fetch("/api/ai/solve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: query.trim(), subject: "sst", mode: "normal" }),
      });
      const data = await res.json();
      setResult(data.result?.answer || data.error || "No response");
    } catch {
      setResult("Failed to get response. Please try again.");
    } finally {
      setIsSolving(false);
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(result);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore
    }
  };

  const quickQuestions = [
    "Explain the Indian Constitution",
    "What are the causes of World War I?",
    "Explain the French Revolution",
    "What is democracy?",
    "Explain the Chipko Movement",
  ];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Globe className="w-6 h-6 text-blue-500" />
          Social Studies Helper
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          History, Geography, Civics, and Economics — all in one place
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {quickQuestions.map((q) => (
          <button
            key={q}
            onClick={() => setQuery(q)}
            className="glass-badge text-xs hover:bg-primary/5 cursor-pointer"
          >
            {q.slice(0, 30)}...
          </button>
        ))}
      </div>

      <Card className="glass-card rounded-2xl">
        <CardContent className="p-4 space-y-3">
          <Textarea
            placeholder="Type your Social Studies question here..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="glass-input min-h-[80px] resize-none bg-transparent border-0 focus-visible:ring-0 p-0"
          />
          <Button
            onClick={handleSolve}
            disabled={isSolving || !query.trim()}
            className="w-full bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white"
          >
            {isSolving ? "Solving..." : <><Sparkles className="w-4 h-4" /> Solve</>}
          </Button>
        </CardContent>
      </Card>

      {isSolving && <ThinkingIndicator message="Researching your question" />}

      {result && !isSolving && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="glass-card-vibrant rounded-2xl">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold flex items-center gap-2">
                  <Lightbulb className="w-4 h-4 text-blue-500" />
                  Answer
                </h3>
                <Button variant="ghost" size="sm" onClick={handleCopy}>
                  {copied ? <><Check className="w-3.5 h-3.5" /> Copied!</> : <><Copy className="w-3.5 h-3.5" /> Copy</>}
                </Button>
              </div>
              <div className="text-sm whitespace-pre-wrap leading-relaxed">{result}</div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
