"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { useQuizStore } from "@/store";
import { SubjectTag } from "@/components/shared/SubjectTag";
import { ThinkingIndicator } from "@/components/ai/ThinkingIndicator";
import type { Subject, QuizDifficulty, QuestionType, Quiz, QuizQuestion } from "@/types";
import {
  FileQuestion,
  Sparkles,
  CheckCircle2,
  XCircle,
  ChevronRight,
  ChevronLeft,
  RotateCcw,
  Trophy,
} from "lucide-react";

const SUBJECTS: Subject[] = ["math", "science", "sanskrit", "sst"];
const DIFFICULTIES: Array<{ id: QuizDifficulty; label: string; icon: string }> = [
  { id: "easy", label: "Easy", icon: "😊" },
  { id: "medium", label: "Medium", icon: "📝" },
  { id: "hard", label: "Hard", icon: "🔥" },
];
const QUESTION_TYPES: Array<{ id: QuestionType; label: string }> = [
  { id: "mcq", label: "Multiple Choice" },
  { id: "true-false", label: "True / False" },
  { id: "short-answer", label: "Short Answer" },
];

export function QuizPage() {
  const {
    subject,
    difficulty,
    questionType,
    topic,
    questionCount,
    isGenerating,
    currentQuiz,
    currentQuestionIndex,
    answers,
    showResults,
    setSubject,
    setDifficulty,
    setQuestionType,
    setTopic,
    setQuestionCount,
    setIsGenerating,
    setCurrentQuiz,
    setAnswer,
    nextQuestion,
    prevQuestion,
    setShowResults,
    resetQuiz,
  } = useQuizStore();

  const [localAnswer, setLocalAnswer] = useState("");

  const handleGenerateQuiz = async () => {
    if (!topic.trim()) return;
    setIsGenerating(true);

    try {
      const res = await fetch("/api/ai/quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic: topic.trim(),
          subject,
          difficulty,
          questionType,
          count: questionCount,
        }),
      });

      const data = await res.json();

      if (data.success && data.questions) {
        const quiz: Quiz = {
          id: `quiz-${Date.now()}`,
          title: data.title || `${topic} Quiz`,
          subject,
          difficulty,
          questions: data.questions,
          score: 0,
          totalQuestions: data.questions.length,
          createdAt: Date.now(),
        };
        setCurrentQuiz(quiz);
      }
    } catch (err) {
      console.error("Quiz generation error:", err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmitAnswer = () => {
    if (!currentQuiz || !localAnswer.trim()) return;
    const currentQ = currentQuiz.questions[currentQuestionIndex];
    setAnswer(currentQ.id, localAnswer.trim());
    setLocalAnswer("");

    if (currentQuestionIndex < currentQuiz.questions.length - 1) {
      nextQuestion();
    } else {
      setShowResults(true);
    }
  };

  const getScore = () => {
    if (!currentQuiz) return 0;
    let correct = 0;
    currentQuiz.questions.forEach((q) => {
      const userAnswer = answers[q.id];
      if (userAnswer && userAnswer.toLowerCase().trim() === q.correctAnswer.toLowerCase().trim()) {
        correct++;
      }
    });
    return correct;
  };

  // Quiz Setup Screen
  if (!currentQuiz) {
    return (
      <div className="space-y-5">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <FileQuestion className="w-6 h-6 text-amber-500" />
            AI Quiz Generator
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Create custom quizzes on any topic
          </p>
        </div>

        {/* Subject */}
        <div className="flex flex-wrap gap-2">
          {SUBJECTS.map((s) => (
            <SubjectTag key={s} subject={s} active={subject === s} onClick={() => setSubject(s)} />
          ))}
        </div>

        {/* Difficulty */}
        <div className="flex gap-1.5 p-1 glass-card rounded-xl">
          {DIFFICULTIES.map((d) => (
            <button
              key={d.id}
              onClick={() => setDifficulty(d.id)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                difficulty === d.id
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {d.icon} {d.label}
            </button>
          ))}
        </div>

        {/* Question Type */}
        <div className="flex gap-1.5 p-1 glass-card rounded-xl">
          {QUESTION_TYPES.map((qt) => (
            <button
              key={qt.id}
              onClick={() => setQuestionType(qt.id)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                questionType === qt.id
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {qt.label}
            </button>
          ))}
        </div>

        {/* Topic Input */}
        <Card className="glass-card rounded-2xl">
          <CardContent className="p-4 space-y-3">
            <Input
              placeholder="Enter topic (e.g., Quadratic Equations, Photosynthesis...)"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="glass-input bg-transparent border-0 focus-visible:ring-0"
            />
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Questions:</span>
                {[3, 5, 10].map((n) => (
                  <button
                    key={n}
                    onClick={() => setQuestionCount(n)}
                    className={`px-2.5 py-1 rounded-lg text-sm font-medium transition-all ${
                      questionCount === n
                        ? "bg-primary text-primary-foreground"
                        : "glass-button"
                    }`}
                  >
                    {n}
                  </button>
                ))}
              </div>
            </div>
            <Button
              onClick={handleGenerateQuiz}
              disabled={isGenerating || !topic.trim()}
              className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white"
            >
              {isGenerating ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Generating Quiz...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Generate Quiz
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {isGenerating && (
          <Card className="glass-card rounded-2xl">
            <CardContent className="p-0">
              <ThinkingIndicator message="Generating your quiz" />
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  // Results Screen
  if (showResults) {
    const score = getScore();
    const percentage = Math.round((score / currentQuiz.totalQuestions) * 100);

    return (
      <div className="space-y-5">
        <div className="text-center">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring" }}>
            <Trophy className="w-16 h-16 mx-auto text-amber-500" />
          </motion.div>
          <h2 className="text-2xl font-bold mt-3">Quiz Complete!</h2>
          <p className="text-muted-foreground">
            You scored {score} out of {currentQuiz.totalQuestions}
          </p>
        </div>

        <Card className="glass-card rounded-2xl">
          <CardContent className="p-5">
            <Progress value={percentage} className="h-3 mb-2" />
            <p className="text-center text-2xl font-bold">{percentage}%</p>
          </CardContent>
        </Card>

        {/* Review Answers */}
        <div className="space-y-3">
          {currentQuiz.questions.map((q, i) => {
            const userAnswer = answers[q.id];
            const isCorrect = userAnswer?.toLowerCase().trim() === q.correctAnswer.toLowerCase().trim();

            return (
              <Card key={q.id} className="glass-card rounded-xl">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    {isCorrect ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1">
                      <p className="text-sm font-medium">Q{i + 1}: {q.question}</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Your answer: {userAnswer || "Not answered"}
                      </p>
                      {!isCorrect && (
                        <p className="text-sm text-emerald-600 dark:text-emerald-400 mt-1">
                          Correct: {q.correctAnswer}
                        </p>
                      )}
                      {q.explanation && (
                        <p className="text-xs text-muted-foreground mt-2 p-2 rounded-lg bg-muted/50">
                          {q.explanation}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Button onClick={resetQuiz} className="w-full" variant="outline">
          <RotateCcw className="w-4 h-4 mr-2" />
          Create New Quiz
        </Button>
      </div>
    );
  }

  // Quiz Taking Screen
  const currentQ = currentQuiz.questions[currentQuestionIndex];
  const progressPercent = ((currentQuestionIndex + 1) / currentQuiz.totalQuestions) * 100;

  return (
    <div className="space-y-5">
      {/* Progress */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={resetQuiz}>
          <RotateCcw className="w-4 h-4" />
        </Button>
        <div className="flex-1">
          <Progress value={progressPercent} className="h-2" />
        </div>
        <span className="text-sm text-muted-foreground">
          {currentQuestionIndex + 1}/{currentQuiz.totalQuestions}
        </span>
      </div>

      {/* Question */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestionIndex}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
        >
          <Card className="glass-card-vibrant rounded-2xl">
            <CardContent className="p-5">
              <h3 className="text-lg font-semibold mb-4">{currentQ.question}</h3>

              {/* Options for MCQ */}
              {currentQ.options && currentQ.type === "mcq" && (
                <div className="space-y-2">
                  {currentQ.options.map((option, i) => (
                    <button
                      key={i}
                      onClick={() => setLocalAnswer(option)}
                      className={`w-full text-left p-3 rounded-xl transition-all text-sm ${
                        localAnswer === option
                          ? "bg-primary text-primary-foreground"
                          : "glass-button"
                      }`}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              )}

              {/* True/False */}
              {currentQ.type === "true-false" && (
                <div className="flex gap-3">
                  {["True", "False"].map((option) => (
                    <button
                      key={option}
                      onClick={() => setLocalAnswer(option)}
                      className={`flex-1 p-3 rounded-xl transition-all text-sm font-medium ${
                        localAnswer === option
                          ? "bg-primary text-primary-foreground"
                          : "glass-button"
                      }`}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              )}

              {/* Short Answer */}
              {currentQ.type === "short-answer" && (
                <Input
                  placeholder="Type your answer..."
                  value={localAnswer}
                  onChange={(e) => setLocalAnswer(e.target.value)}
                  className="glass-input bg-transparent border-0 focus-visible:ring-0"
                />
              )}
            </CardContent>
          </Card>
        </motion.div>
      </AnimatePresence>

      {/* Navigation */}
      <div className="flex items-center justify-between">
        <Button
          variant="outline"
          onClick={prevQuestion}
          disabled={currentQuestionIndex === 0}
          className="glass-button"
        >
          <ChevronLeft className="w-4 h-4 mr-1" />
          Previous
        </Button>
        <Button
          onClick={handleSubmitAnswer}
          disabled={!localAnswer.trim()}
          className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white"
        >
          {currentQuestionIndex < currentQuiz.totalQuestions - 1 ? (
            <>
              Next
              <ChevronRight className="w-4 h-4 ml-1" />
            </>
          ) : (
            <>
              <CheckCircle2 className="w-4 h-4 mr-1" />
              Submit
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
