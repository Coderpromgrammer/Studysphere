"use client";

import React, { useEffect } from "react";
import { useNavStore } from "@/store";
import { Sidebar } from "./Sidebar";
import { TopBar } from "./TopBar";
import { BottomNav } from "./BottomNav";
import { useIsMobile } from "@/hooks/use-mobile";

export function AppShell({ children }: { children: React.ReactNode }) {
  const currentPage = useNavStore((s) => s.currentPage);
  const isMobile = useIsMobile();

  // Close sidebar on page change (mobile)
  useEffect(() => {
    useNavStore.getState().setSidebarOpen(false);
  }, [currentPage]);

  return (
    <div className="min-h-screen flex flex-col animated-gradient-bg relative overflow-hidden">
      {/* Background Orbs */}
      <div className="bg-orb bg-orb-1" />
      <div className="bg-orb bg-orb-2" />
      <div className="bg-orb bg-orb-3" />

      {/* Desktop Sidebar */}
      {!isMobile && <Sidebar />}

      {/* Top Bar */}
      <TopBar />

      {/* Main Content */}
      <main
        className={`flex-1 ${!isMobile ? "ml-64" : ""} pt-16 pb-20 relative z-10`}
      >
        <div className="page-transition p-4 md:p-6 lg:p-8 max-w-5xl mx-auto">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Nav */}
      {isMobile && <BottomNav />}

      {/* Mobile Sidebar Overlay */}
      {isMobile && <MobileSidebarOverlay />}
    </div>
  );
}

function MobileSidebarOverlay() {
  const sidebarOpen = useNavStore((s) => s.sidebarOpen);
  const setSidebarOpen = useNavStore((s) => s.setSidebarOpen);

  if (!sidebarOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/30 z-40 backdrop-blur-sm"
        onClick={() => setSidebarOpen(false)}
      />
      {/* Sidebar */}
      <div className="fixed left-0 top-0 bottom-0 z-50 w-64">
        <Sidebar />
      </div>
    </>
  );
}
