"use client";

import { useNavStore } from "@/store";
import type { PageId } from "@/types";
import {
  LayoutDashboard,
  Brain,
  FileQuestion,
  BookOpen,
  Users,
  TrendingUp,
  Settings,
  Calculator,
  FlaskConical,
  BookMarked,
  Globe,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Fragment } from "react";

const NAV_ITEMS: Array<{
  id: PageId;
  label: string;
  icon: React.ReactNode;
  section?: string;
}> = [
  { id: "dashboard", label: "Dashboard", icon: <LayoutDashboard className="w-5 h-5" /> },
  { id: "solver", label: "AI Solver", icon: <Brain className="w-5 h-5" /> },
  { id: "quiz", label: "Quiz", icon: <FileQuestion className="w-5 h-5" /> },
  { id: "notebook", label: "Notebook", icon: <BookOpen className="w-5 h-5" /> },
  { id: "classroom", label: "Classroom", icon: <Users className="w-5 h-5" /> },
  { id: "progress", label: "Progress", icon: <TrendingUp className="w-5 h-5" /> },
  { id: "settings", label: "Settings", icon: <Settings className="w-5 h-5" /> },
  { id: "math-helper", label: "Math Helper", icon: <Calculator className="w-5 h-5" />, section: "Subjects" },
  { id: "science-helper", label: "Science Helper", icon: <FlaskConical className="w-5 h-5" />, section: "Subjects" },
  { id: "sanskrit-helper", label: "Sanskrit Helper", icon: <BookMarked className="w-5 h-5" />, section: "Subjects" },
  { id: "sst-helper", label: "SST Helper", icon: <Globe className="w-5 h-5" />, section: "Subjects" },
];

// Pre-compute section headers
const sectionsShown = new Set<string>();

export function Sidebar() {
  const currentPage = useNavStore((s) => s.currentPage);
  const setPage = useNavStore((s) => s.setPage);

  // Reset section tracking for each render
  const renderedSections = new Set<string>();

  return (
    <aside className="glass-sidebar h-full w-64 flex flex-col">
      {/* Logo */}
      <div className="p-5 flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-indigo-500 flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="font-bold text-lg gradient-text">StudySphere</h1>
          <p className="text-[10px] text-muted-foreground -mt-0.5">AI Learning Platform</p>
        </div>
      </div>

      {/* Nav Items */}
      <nav className="flex-1 px-3 space-y-0.5 overflow-y-auto touch-scroll">
        {NAV_ITEMS.map((item) => {
          const showSection = item.section && !renderedSections.has(item.section);
          if (item.section) renderedSections.add(item.section);

          return (
            <Fragment key={item.id}>
              {showSection && (
                <div className="pt-4 pb-1 px-3 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                  {item.section}
                </div>
              )}
              <button
                onClick={() => setPage(item.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all",
                  currentPage === item.id
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
                )}
              >
                {item.icon}
                {item.label}
              </button>
            </Fragment>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-border/30">
        <div className="glass-badge text-xs w-full justify-center">
          <Sparkles className="w-3 h-3" />
          AI-Powered Learning
        </div>
      </div>
    </aside>
  );
}
