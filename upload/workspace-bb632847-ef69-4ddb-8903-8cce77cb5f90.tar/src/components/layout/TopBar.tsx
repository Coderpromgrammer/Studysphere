"use client";

import { useNavStore } from "@/store";
import { useIsMobile } from "@/hooks/use-mobile";
import { Menu, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

export function TopBar() {
  const toggleSidebar = useNavStore((s) => s.toggleSidebar);
  const isMobile = useIsMobile();

  return (
    <header className="fixed top-0 left-0 right-0 z-30 glass-nav border-b border-border/30 safe-bottom">
      <div className={`flex items-center justify-between h-14 px-4 ${!isMobile ? "ml-64" : ""}`}>
        <div className="flex items-center gap-3">
          {isMobile && (
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleSidebar}
              className="glass-button"
            >
              <Menu className="w-5 h-5" />
            </Button>
          )}
          {isMobile && (
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500 to-indigo-500 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold gradient-text">StudySphere</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <div className="glass-badge text-xs">
            <Sparkles className="w-3 h-3" />
            Demo Mode
          </div>
        </div>
      </div>
    </header>
  );
}
