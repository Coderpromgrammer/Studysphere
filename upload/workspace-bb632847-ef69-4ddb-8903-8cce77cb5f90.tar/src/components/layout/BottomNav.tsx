"use client";

import { useNavStore } from "@/store";
import type { PageId } from "@/types";
import {
  LayoutDashboard,
  Brain,
  FileQuestion,
  BookOpen,
  Users,
  TrendingUp,
  Settings,
} from "lucide-react";
import { cn } from "@/lib/utils";

const BOTTOM_NAV_ITEMS: Array<{
  id: PageId;
  label: string;
  icon: React.ReactNode;
}> = [
  { id: "dashboard", label: "Home", icon: <LayoutDashboard className="w-5 h-5" /> },
  { id: "quiz", label: "Quiz", icon: <FileQuestion className="w-5 h-5" /> },
  { id: "solver", label: "Solve", icon: <Brain className="w-6 h-6" /> }, // Center button
  { id: "notebook", label: "Notes", icon: <BookOpen className="w-5 h-5" /> },
  { id: "classroom", label: "Class", icon: <Users className="w-5 h-5" /> },
];

export function BottomNav() {
  const currentPage = useNavStore((s) => s.currentPage);
  const setPage = useNavStore((s) => s.setPage);

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 glass-nav border-t border-border/30 safe-bottom">
      <div className="flex items-center justify-around h-16 px-2">
        {BOTTOM_NAV_ITEMS.map((item, idx) => {
          const isCenter = idx === 2; // Solve button

          if (isCenter) {
            return (
              <button
                key={item.id}
                onClick={() => setPage(item.id)}
                className={cn(
                  "relative -mt-5 w-14 h-14 rounded-full flex flex-col items-center justify-center shadow-lg transition-all",
                  currentPage === item.id
                    ? "bg-gradient-to-br from-violet-500 to-indigo-500 text-white scale-105"
                    : "bg-primary text-primary-foreground hover:scale-105"
                )}
              >
                {item.icon}
                <span className="text-[9px] font-medium mt-0.5">{item.label}</span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => setPage(item.id)}
              className={cn(
                "flex flex-col items-center justify-center gap-0.5 min-w-[48px] min-h-[44px] transition-colors",
                currentPage === item.id
                  ? "text-primary"
                  : "text-muted-foreground"
              )}
            >
              {item.icon}
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
