"use client";

import { useNavStore } from "@/store";
import { AppShell } from "@/components/layout/AppShell";
import { DashboardPage } from "@/components/pages/DashboardPage";
import { SolverPage } from "@/components/pages/SolverPage";
import { QuizPage } from "@/components/pages/QuizPage";
import { NotebookPage } from "@/components/pages/NotebookPage";
import { ClassroomPage } from "@/components/pages/ClassroomPage";
import { ProgressPage } from "@/components/pages/ProgressPage";
import { SettingsPage } from "@/components/pages/SettingsPage";
import { MathHelperPage } from "@/components/pages/MathHelperPage";
import { ScienceHelperPage } from "@/components/pages/ScienceHelperPage";
import { SanskritHelperPage } from "@/components/pages/SanskritHelperPage";
import { SSTHelperPage } from "@/components/pages/SSTHelperPage";
import type { PageId } from "@/types";

const PAGE_MAP: Record<PageId, React.ComponentType> = {
  dashboard: DashboardPage,
  solver: SolverPage,
  quiz: QuizPage,
  notebook: NotebookPage,
  classroom: ClassroomPage,
  progress: ProgressPage,
  settings: SettingsPage,
  "math-helper": MathHelperPage,
  "science-helper": ScienceHelperPage,
  "sanskrit-helper": SanskritHelperPage,
  "sst-helper": SSTHelperPage,
};

export function AuthenticatedApp() {
  const currentPage = useNavStore((s) => s.currentPage);
  const PageComponent = PAGE_MAP[currentPage] || DashboardPage;

  return (
    <AppShell>
      <PageComponent />
    </AppShell>
  );
}
