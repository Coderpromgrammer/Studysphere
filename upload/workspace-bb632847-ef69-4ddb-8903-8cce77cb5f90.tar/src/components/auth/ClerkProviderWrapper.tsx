"use client";

import React from "react";

// ClerkProviderWrapper — Dynamic import wrapper for Clerk
// This avoids build errors when Clerk is not configured

interface ClerkProviderWrapperProps {
  children: React.ReactNode;
}

export function ClerkProviderWrapper({ children }: ClerkProviderWrapperProps) {
  const publishableKey = process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY;

  if (!publishableKey) {
    return <>{children}</>;
  }

  return <ClerkLoader publishableKey={publishableKey}>{children}</ClerkLoader>;
}

function ClerkLoader({ children, publishableKey }: { children: React.ReactNode; publishableKey: string }) {
  const [ClerkProvider, setClerkProvider] = React.useState<React.ComponentType<{ publishableKey: string; children: React.ReactNode }> | null>(null);
  const [failed, setFailed] = React.useState(false);

  React.useEffect(() => {
    import("@clerk/nextjs")
      .then((mod) => setClerkProvider(() => mod.ClerkProvider))
      .catch(() => setFailed(true));
  }, []);

  if (failed || !ClerkProvider) {
    return <>{children}</>;
  }

  return <ClerkProvider publishableKey={publishableKey}>{children}</ClerkProvider>;
}
