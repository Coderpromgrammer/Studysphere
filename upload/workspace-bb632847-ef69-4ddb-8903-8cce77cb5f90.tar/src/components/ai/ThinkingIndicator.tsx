"use client";

import { motion } from "framer-motion";

interface ThinkingIndicatorProps {
  message?: string;
}

export function ThinkingIndicator({ message = "AI is thinking" }: ThinkingIndicatorProps) {
  return (
    <div className="flex items-center gap-3 p-4">
      <div className="flex gap-1">
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            className="w-2 h-2 rounded-full bg-primary"
            animate={{ y: [0, -6, 0] }}
            transition={{
              duration: 0.6,
              repeat: Infinity,
              delay: i * 0.15,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>
      <span className="text-sm text-muted-foreground">{message}...</span>
    </div>
  );
}
