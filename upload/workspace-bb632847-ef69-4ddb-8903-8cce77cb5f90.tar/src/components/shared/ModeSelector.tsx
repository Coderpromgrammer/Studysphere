"use client";

import { cn } from "@/lib/utils";

interface ModeSelectorProps {
  modes: Array<{ id: string; label: string; icon?: string }>;
  activeMode: string;
  onSelect: (mode: string) => void;
  className?: string;
}

export function ModeSelector({ modes, activeMode, onSelect, className }: ModeSelectorProps) {
  return (
    <div className={cn("flex gap-1.5 p-1 glass-card rounded-xl", className)}>
      {modes.map((mode) => (
        <button
          key={mode.id}
          onClick={() => onSelect(mode.id)}
          className={cn(
            "px-3 py-1.5 rounded-lg text-sm font-medium transition-all",
            activeMode === mode.id
              ? "bg-primary text-primary-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
          )}
        >
          {mode.icon && <span className="mr-1">{mode.icon}</span>}
          {mode.label}
        </button>
      ))}
    </div>
  );
}
