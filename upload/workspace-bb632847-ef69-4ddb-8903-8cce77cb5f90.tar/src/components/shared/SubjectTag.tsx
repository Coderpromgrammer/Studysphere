"use client";

import { cn } from "@/lib/utils";
import type { Subject } from "@/types";
import { SUBJECT_CONFIG } from "@/types";

interface SubjectTagProps {
  subject: Subject;
  active?: boolean;
  onClick?: () => void;
  size?: "sm" | "md";
}

export function SubjectTag({ subject, active, onClick, size = "md" }: SubjectTagProps) {
  const config = SUBJECT_CONFIG[subject];

  return (
    <button
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full font-medium transition-all",
        size === "sm" ? "px-2.5 py-1 text-xs" : "px-3.5 py-1.5 text-sm",
        active
          ? "glass-badge bg-primary/10 text-primary border-primary/30"
          : "glass-badge hover:bg-primary/5",
        onClick && "cursor-pointer"
      )}
    >
      <span className={cn("text-base", config.color)}>
        {subject === "math" ? "📐" : subject === "science" ? "🔬" : subject === "sanskrit" ? "🕉️" : "🌍"}
      </span>
      <span>{config.label}</span>
    </button>
  );
}
