"use client";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface ActionButton {
  label: string;
  icon?: React.ReactNode;
  onClick: () => void;
  variant?: "default" | "outline" | "ghost" | "secondary";
  className?: string;
}

interface ActionButtonsProps {
  buttons: ActionButton[];
  className?: string;
}

export function ActionButtons({ buttons, className }: ActionButtonsProps) {
  return (
    <div className={cn("flex flex-wrap gap-2", className)}>
      {buttons.map((btn, i) => (
        <Button
          key={i}
          variant={btn.variant || "outline"}
          size="sm"
          onClick={btn.onClick}
          className={cn("gap-2", btn.className)}
        >
          {btn.icon}
          {btn.label}
        </Button>
      ))}
    </div>
  );
}
