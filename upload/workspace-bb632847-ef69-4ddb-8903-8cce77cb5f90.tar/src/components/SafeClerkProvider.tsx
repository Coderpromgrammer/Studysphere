"use client";

import React from "react";

// SafeClerkProvider — Works with or without Clerk keys
// If Clerk publishable key is available, wraps with ClerkProvider
// Otherwise, renders children directly (demo mode)

interface SafeClerkProviderProps {
  children: React.ReactNode;
}

export function SafeClerkProvider({ children }: SafeClerkProviderProps) {
  const publishableKey = process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY;

  // If no Clerk key, render children directly (demo mode)
  if (!publishableKey) {
    return <>{children}</>;
  }

  // With Clerk key, use the ClerkProvider
  // We use a component-based approach to avoid try/catch JSX issues
  return <ClerkWrapper publishableKey={publishableKey}>{children}</ClerkWrapper>;
}

// Separate component that uses Clerk conditionally
function ClerkWrapper({ children, publishableKey }: { children: React.ReactNode; publishableKey: string }) {
  // Dynamic import approach - only import Clerk when needed
  // This avoids build errors when @clerk/nextjs is not configured
  const [ClerkProvider, setClerkProvider] = React.useState<React.ComponentType<{ publishableKey: string; children: React.ReactNode }> | null>(null);
  const [loadError, setLoadError] = React.useState(false);

  React.useEffect(() => {
    import("@clerk/nextjs")
      .then((mod) => setClerkProvider(() => mod.ClerkProvider))
      .catch(() => setLoadError(true));
  }, []);

  if (loadError || !ClerkProvider) {
    // Fallback: render without Clerk
    if (loadError) return <>{children}</>;
    return <>{children}</>; // Loading state
  }

  return <ClerkProvider publishableKey={publishableKey}>{children}</ClerkProvider>;
}
